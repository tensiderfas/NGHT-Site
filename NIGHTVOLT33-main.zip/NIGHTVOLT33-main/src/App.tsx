/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Partners } from './components/Partners';
import { AboutUs } from './components/AboutUs';
import { Benefits } from './components/Benefits';
import { Comparison } from './components/Comparison';
import { Pricing } from './components/Pricing';
import { FAQ } from './components/FAQ';
import { ContactModal } from './components/ContactModal';
import { AuthModal } from './components/AuthModal';
import { DashboardView } from './components/DashboardView';
import { DistributionPartnersPage } from './components/DistributionPartnersPage';
import { AboutLabelPage } from './components/AboutLabelPage';
import { LogoIcon } from './components/CustomIcons';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Mail, Send } from 'lucide-react';

export default function App() {
  // Navigation & View States
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [currentView, setCurrentView] = useState<'landing' | 'partners-page' | 'about-page'>('landing');
  
  // Modals
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [selectedPlanForContact, setSelectedPlanForContact] = useState('');
  
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Load user login state if saved
  useEffect(() => {
    const savedUser = localStorage.getItem('nv_user_email');
    if (savedUser) {
      setUserEmail(savedUser);
      setIsLoggedIn(true);
    }
  }, []);

  const handleLoginSuccess = (email: string) => {
    localStorage.setItem('nv_user_email', email);
    setUserEmail(email);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('nv_user_email');
    setUserEmail('');
    setIsLoggedIn(false);
  };

  const handlePlanSelect = (planName: string) => {
    setSelectedPlanForContact(planName);
    setIsContactOpen(true);
  };

  const handleNavigate = (sectionId: string) => {
    if (sectionId === 'partners-page' || sectionId === 'partners') {
      setCurrentView('partners-page');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    if (sectionId === 'about-page') {
      setCurrentView('about-page');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    
    setCurrentView('landing');
    setTimeout(() => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 font-sans selection:bg-brand-light selection:text-brand-dark overflow-x-hidden">
      
      <AnimatePresence mode="wait">
        {isLoggedIn ? (
          /* PERSISTENT CABINET VIEW */
          <motion.div
            key="dashboard-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <DashboardView userEmail={userEmail} onLogout={handleLogout} />
          </motion.div>
        ) : (
          /* STANDARD LANDING SHOWCASE */
          <motion.div
            key="landing-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col min-h-screen justify-between"
          >
            {/* Header */}
            <Header 
              onLoginClick={() => window.open('https://account.nightvolt.ru', '_blank', 'noopener,noreferrer')}
              onRegisterClick={() => window.open('https://account.nightvolt.ru', '_blank', 'noopener,noreferrer')}
              onNavigate={handleNavigate}
            />

            {/* Core page segments */}
            <main className="flex-grow">
              <AnimatePresence mode="wait">
                {currentView === 'landing' ? (
                  <motion.div
                    key="landing-view"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.35, ease: 'easeInOut' }}
                  >
                    <Hero 
                      onRegisterClick={() => { setSelectedPlanForContact('Дистрибуция'); setIsContactOpen(true); }}
                      onLearnMoreClick={() => handleNavigate('about-page')}
                    />
                    <Partners />
                    <AboutUs />
                    <Benefits />
                    <Comparison />
                    <Pricing onPlanSelect={handlePlanSelect} />
                    <FAQ onContactClick={() => { setSelectedPlanForContact(''); setIsContactOpen(true); }} />
                  </motion.div>
                ) : currentView === 'partners-page' ? (
                  <motion.div
                    key="partners-view"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.35, ease: 'easeInOut' }}
                  >
                    <DistributionPartnersPage 
                      onBack={() => {
                        setCurrentView('landing');
                        window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
                      }} 
                      onContactClick={handlePlanSelect} 
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="about-label-view"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.35, ease: 'easeInOut' }}
                  >
                    <AboutLabelPage 
                      onBack={() => {
                        setCurrentView('landing');
                        window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
                      }} 
                      onContactClick={handlePlanSelect} 
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </main>

            {/* Sleek footer matching visual reference SaaS style */}
            <footer className="bg-slate-900 text-slate-400 border-t border-slate-800">
              <div className="mx-auto max-w-7xl px-6 py-12 md:py-16 space-y-12">
                
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                  {/* Branding Column */}
                  <div className="md:col-span-5 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="text-brand-primary">
                        <LogoIcon size={32} />
                      </div>
                      <div>
                        <h4 className="font-display font-extrabold text-base text-white tracking-tight leading-none">
                          NIGHTVOLT
                        </h4>
                        <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block mt-0.5">
                          Distribution
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-400 max-w-sm leading-relaxed font-medium">
                      Современная платформа цифровой музыкальной дистрибуции для независимых музыкантов и творческих объединений. Управляйте своими правами без посредников.
                    </p>
                    <div className="flex items-center gap-2 text-[11px] text-brand-primary font-bold">
                      <ShieldCheck className="h-4 w-4" />
                      <span>Полностью лицензированный дистрибьютор</span>
                    </div>
                  </div>

                  {/* Links columns */}
                  <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-6">
                    <div className="space-y-3.5">
                      <h5 className="text-xs font-bold text-white uppercase tracking-wider">Дистрибуция</h5>
                      <ul className="space-y-2 text-xs font-semibold">
                        <li><button onClick={() => handleNavigate('partners-page')} className="hover:text-white transition-colors text-left cursor-pointer">Яндекс Музыка</button></li>
                        <li><button onClick={() => handleNavigate('partners-page')} className="hover:text-white transition-colors text-left cursor-pointer">VK Музыка</button></li>
                        <li><button onClick={() => handleNavigate('partners-page')} className="hover:text-white transition-colors text-left cursor-pointer">Звук</button></li>
                        <li><button onClick={() => handleNavigate('partners-page')} className="hover:text-white transition-colors text-left cursor-pointer">Spotify & Apple Music</button></li>
                      </ul>
                    </div>

                    <div className="space-y-3.5">
                      <h5 className="text-xs font-bold text-white uppercase tracking-wider">Платформа</h5>
                      <ul className="space-y-2 text-xs font-semibold">
                        <li><a href="#benefits" className="hover:text-white transition-colors">Преимущества</a></li>
                        <li><a href="#pricing" className="hover:text-white transition-colors">Тарифы</a></li>
                        <li><button onClick={() => window.open('https://account.nightvolt.ru', '_blank', 'noopener,noreferrer')} className="hover:text-white transition-colors text-left">Личный кабинет</button></li>
                        <li><a href="#faq" className="hover:text-white transition-colors">Помощь и FAQ</a></li>
                      </ul>
                    </div>

                    <div className="space-y-3.5">
                      <h5 className="text-xs font-bold text-white uppercase tracking-wider">Документы</h5>
                      <ul className="space-y-2 text-xs font-semibold">
                        <li><span className="cursor-pointer hover:text-white transition-colors">Лицензионная оферта</span></li>
                        <li><span className="cursor-pointer hover:text-white transition-colors">Политика конфиденциальности</span></li>
                        <li><span className="cursor-pointer hover:text-white transition-colors">Правила модерации релизов</span></li>
                      </ul>
                    </div>

                    <div className="space-y-3.5 col-span-2 sm:col-span-1">
                      <h5 className="text-xs font-bold text-white uppercase tracking-wider">Контакты</h5>
                      <ul className="space-y-2.5 text-xs font-semibold">
                        <li className="flex flex-col gap-0.5">
                          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Поддержка</span>
                          <a href="mailto:nightvolt@internet.ru" className="text-slate-300 hover:text-white transition-colors break-all">nightvolt@internet.ru</a>
                        </li>
                        <li className="flex flex-col gap-0.5">
                          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Сотрудничество</span>
                          <a href="mailto:label@nightvolt.ru" className="text-slate-300 hover:text-white transition-colors break-all">label@nightvolt.ru</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="h-px bg-slate-800" />

                {/* Copyright info */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-semibold text-slate-500">
                  <p>© 2026 NIGHTVOLT Distribution. Все права защищены.</p>
                  <div className="flex gap-4">
                    <span className="hover:text-slate-400 cursor-pointer">Договор дистрибуции</span>
                    <span>•</span>
                    <span className="hover:text-slate-400 cursor-pointer">Контакты</span>
                  </div>
                </div>

              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Modals */}
      <ContactModal 
        isOpen={isContactOpen} 
        onClose={() => { setIsContactOpen(false); setSelectedPlanForContact(''); }} 
        selectedPlan={selectedPlanForContact}
      />

      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        onSuccess={handleLoginSuccess}
        defaultMode={authMode}
      />

    </div>
  );
}
