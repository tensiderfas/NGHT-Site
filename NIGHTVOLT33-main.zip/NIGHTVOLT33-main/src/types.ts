/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FAQItem {
  question: string;
  answer: string;
}

export interface BenefitItem {
  id: string;
  title: string;
  description: string;
  iconName: string; // Used to select custom built SVG icon
}

export interface ComparisonRow {
  feature: string;
  nightvolt: string | boolean;
  competitors: string | boolean;
  isCustomHighlight?: boolean;
}

export interface PricePlan {
  id: string;
  name: string;
  priceMonthly: number;
  priceAnnually: number;
  description: string;
  isPopular?: boolean;
  isMaximum?: boolean;
  features: string[];
}

export interface Release {
  id: string;
  title: string;
  artist: string;
  genre: string;
  releaseDate: string;
  upc?: string;
  status: 'draft' | 'moderation' | 'approved' | 'rejected' | 'released';
  coverUrl?: string;
  tracksCount: number;
}

export interface SupportTicket {
  id: string;
  subject: string;
  message: string;
  date: string;
  status: 'open' | 'resolved';
}

export interface FinancialRecord {
  id: string;
  date: string;
  type: 'payout' | 'royalty';
  amount: number;
  status: 'completed' | 'processing';
  description: string;
}
