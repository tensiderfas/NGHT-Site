/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, Play, Users, Landmark, Plus, FileAudio, 
  HelpCircle, Settings, LogOut, ChevronRight, CheckCircle, 
  Clock, AlertCircle, Upload, Check, DollarSign, Wallet, ArrowUpRight, BarChart3, ListMusic
} from 'lucide-react';
import { LogoIcon, PlatformLogo } from './CustomIcons';
import { Release, FinancialRecord, SupportTicket } from '../types';
import { INITIAL_RELEASES, INITIAL_FINANCIALS } from '../data';

interface DashboardViewProps {
  userEmail: string;
  onLogout: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ userEmail, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'catalog' | 'analytics' | 'financials' | 'support'>('overview');
  const [releases, setReleases] = useState<Release[]>([]);
  const [financials, setFinancials] = useState<FinancialRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([
    { id: 't-1', subject: 'Запрос питчинга для трека "Solar Wind"', message: 'Прошу рассмотреть трек для редакторских плейлистов Яндекс Музыки.', date: '2026-06-20', status: 'resolved' }
  ]);
  
  // Create Release Form State
  const [isCreatingRelease, setIsCreatingRelease] = useState(false);
  const [newReleaseStep, setNewReleaseStep] = useState(1);
  const [formRelease, setFormRelease] = useState({
    title: '',
    artist: 'NIGHTVOLT Artist',
    genre: 'Electronic',
    releaseDate: '2026-07-10',
    tracksCount: 1,
    coverPreset: 'sunset'
  });

  // Support Form State
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [isSubmittingTicket, setIsSubmittingTicket] = useState(false);

  // Financial States
  const [balance, setBalance] = useState(12090.70);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [payoutCard, setPayoutCard] = useState('');
  const [payoutSuccess, setPayoutSuccess] = useState(false);
  const [isRequestingPayout, setIsRequestingPayout] = useState(false);

  const coverPresets = [
    { id: 'sunset', label: 'Sunset Glow', url: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=400&h=400&q=80' },
    { id: 'neon', label: 'SaaS Grid', url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&h=400&q=80' },
    { id: 'space', label: 'Cosmic Dust', url: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=400&h=400&q=80' },
    { id: 'minimal', label: 'Clean Wave', url: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=400&h=400&q=80' }
  ];

  // Load from LocalStorage or default
  useEffect(() => {
    const savedReleases = localStorage.getItem('nv_releases');
    if (savedReleases) {
      setReleases(JSON.parse(savedReleases));
    } else {
      setReleases(INITIAL_RELEASES);
    }

    const savedFinancials = localStorage.getItem('nv_financials');
    if (savedFinancials) {
      setFinancials(JSON.parse(savedFinancials));
    } else {
      setFinancials(INITIAL_FINANCIALS);
    }
    
    const savedBalance = localStorage.getItem('nv_balance');
    if (savedBalance) {
      setBalance(parseFloat(savedBalance));
    }
  }, []);

  const saveToStorage = (updatedReleases: Release[]) => {
    localStorage.setItem('nv_releases', JSON.stringify(updatedReleases));
    setReleases(updatedReleases);
  };

  const saveFinancialsToStorage = (updatedFin: FinancialRecord[], newBalance: number) => {
    localStorage.setItem('nv_financials', JSON.stringify(updatedFin));
    localStorage.setItem('nv_balance', newBalance.toString());
    setFinancials(updatedFin);
    setBalance(newBalance);
  };

  // Simulate automated transition from moderation to approved
  useEffect(() => {
    const checkModeration = setInterval(() => {
      const pendingIndex = releases.findIndex(r => r.status === 'moderation');
      if (pendingIndex !== -1) {
        // Change state randomly after sometime
        const updated = [...releases];
        updated[pendingIndex] = {
          ...updated[pendingIndex],
          status: 'approved',
          upc: `UPC-${Math.floor(100000000000 + Math.random() * 900000000000)}`
        };
        saveToStorage(updated);
      }
    }, 15000); // Check every 15s

    return () => clearInterval(checkModeration);
  }, [releases]);

  const handleCreateRelease = (e: React.FormEvent) => {
    e.preventDefault();
    const chosenPreset = coverPresets.find(p => p.id === formRelease.coverPreset);
    
    const newRel: Release = {
      id: `rel-${Date.now()}`,
      title: formRelease.title || "Untitled Release",
      artist: formRelease.artist || "Unknown Artist",
      genre: formRelease.genre,
      releaseDate: formRelease.releaseDate,
      upc: 'Pending',
      status: 'moderation',
      coverUrl: chosenPreset?.url || coverPresets[0].url,
      tracksCount: formRelease.tracksCount
    };

    const updated = [newRel, ...releases];
    saveToStorage(updated);
    
    // reset
    setFormRelease({
      title: '',
      artist: 'NIGHTVOLT Artist',
      genre: 'Electronic',
      releaseDate: '2026-07-10',
      tracksCount: 1,
      coverPreset: 'sunset'
    });
    setNewReleaseStep(1);
    setIsCreatingRelease(false);
    setActiveTab('catalog');
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject || !ticketMessage) return;

    setIsSubmittingTicket(true);
    setTimeout(() => {
      const newTicket: SupportTicket = {
        id: `t-${Date.now()}`,
        subject: ticketSubject,
        message: ticketMessage,
        date: new Date().toISOString().split('T')[0],
        status: 'open'
      };
      setTickets([newTicket, ...tickets]);
      setTicketSubject('');
      setTicketMessage('');
      setIsSubmittingTicket(false);
    }, 800);
  };

  const handleRequestPayout = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payoutAmount);
    if (isNaN(amt) || amt <= 0 || amt > balance) return;

    const newRecord: FinancialRecord = {
      id: `fin-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      type: 'payout',
      amount: -amt,
      status: 'processing',
      description: `Запрос выплаты на карту ${payoutCard.replace(/(\d{4})\s?(\d{4})\s?(\d{4})\s?(\d{4})/, '**** **** **** $4')}`
    };

    const updated = [newRecord, ...financials];
    saveFinancialsToStorage(updated, balance - amt);
    setPayoutSuccess(true);
    setPayoutAmount('');
    setPayoutCard('');
    setTimeout(() => {
      setPayoutSuccess(false);
      setIsRequestingPayout(false);
    }, 2500);
  };

  // Mock stats for overview
  const totalStreams = 348291;
  const monthlyListeners = 42810;
  
  return (
    <div className="min-h-screen bg-slate-50 flex font-sans text-slate-800">
      
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0 hidden md:flex">
        {/* Logo block */}
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <LogoIcon className="text-brand-primary" size={32} />
          <div>
            <h1 className="font-display font-bold text-base text-slate-900 leading-none">NIGHTVOLT</h1>
            <span className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Distribution</span>
          </div>
        </div>

        {/* User Info */}
        <div className="px-6 py-4 border-b border-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-full bg-brand-light flex items-center justify-center text-brand-primary font-bold text-sm">
              {userEmail ? userEmail[0].toUpperCase() : 'U'}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs text-slate-400 font-medium truncate">Личный кабинет</p>
              <p className="text-xs font-semibold text-slate-800 truncate">{userEmail || 'artist@nightvolt.ru'}</p>
            </div>
          </div>
        </div>

        {/* Nav list */}
        <nav className="flex-1 p-4 space-y-1">
          {[
            { id: 'overview', label: 'Панель управления', icon: TrendingUp },
            { id: 'catalog', label: 'Мой каталог', icon: ListMusic },
            { id: 'analytics', label: 'Аналитика', icon: BarChart3 },
            { id: 'financials', label: 'Финансы и выплаты', icon: Landmark },
            { id: 'support', label: 'Служба поддержки', icon: HelpCircle },
          ].map((item) => {
            const IconComp = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id as any); setIsCreatingRelease(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive 
                    ? 'bg-brand-light text-brand-dark' 
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-950'
                }`}
              >
                <IconComp className={`h-4 w-4 ${isActive ? 'text-brand-primary' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {isActive && <div className="ml-auto h-1.5 w-1.5 rounded-full bg-brand-primary" />}
              </button>
            );
          })}
        </nav>

        {/* Quick launch create release */}
        <div className="p-4 border-t border-slate-100">
          <button
            onClick={() => setIsCreatingRelease(true)}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-brand-primary px-4 py-2.5 text-xs font-bold text-white shadow-md hover:bg-brand-hover transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Создать релиз</span>
          </button>
        </div>

        {/* Logout bottom */}
        <div className="p-4 border-t border-slate-100">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold text-rose-500 hover:bg-rose-50 transition-colors"
          >
            <LogOut className="h-4 w-4" />
            <span>Вернуться на сайт</span>
          </button>
        </div>
      </aside>

      {/* Main Container */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 shrink-0 md:px-8">
          <div className="flex items-center gap-2 md:hidden">
            <LogoIcon className="text-brand-primary" size={28} />
            <span className="font-display font-extrabold text-sm text-slate-900 tracking-tight">NIGHTVOLT</span>
          </div>

          <div className="hidden md:block">
            <h2 className="font-display text-lg font-bold text-slate-800">
              {activeTab === 'overview' && 'Обзор аккаунта'}
              {activeTab === 'catalog' && 'Мой каталог релизов'}
              {activeTab === 'analytics' && 'Статистика и аналитика'}
              {activeTab === 'financials' && 'Финансовый баланс'}
              {activeTab === 'support' && 'Обращения в поддержку'}
              {isCreatingRelease && 'Создание нового релиза'}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            {/* Quick stats on top */}
            <div className="hidden lg:flex items-center gap-4 text-xs font-medium text-slate-500">
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 rounded-md">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                <span>Сервер дистрибуции: Активен</span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 rounded-md">
                <span>Баланс:</span>
                <span className="font-bold text-slate-950">{balance.toLocaleString('ru-RU')} ₽</span>
              </div>
            </div>

            <button 
              onClick={onLogout} 
              className="md:hidden p-2 text-rose-500 hover:bg-rose-50 rounded-lg"
              title="Выйти"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </header>

        {/* Main Workspace */}
        <div className="p-6 md:p-8 flex-1 max-w-5xl w-full mx-auto">
          
          {/* Mobile Tabs Switcher */}
          <div className="flex gap-1 overflow-x-auto pb-4 md:hidden scrollbar-none">
            {[
              { id: 'overview', label: 'Обзор' },
              { id: 'catalog', label: 'Каталог' },
              { id: 'analytics', label: 'Статистика' },
              { id: 'financials', label: 'Финансы' },
              { id: 'support', label: 'Поддержка' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id as any); setIsCreatingRelease(false); }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  activeTab === tab.id && !isCreatingRelease
                    ? 'bg-brand-primary text-white'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
            <button
              onClick={() => setIsCreatingRelease(true)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1 ${
                isCreatingRelease ? 'bg-brand-primary text-white' : 'bg-brand-light text-brand-dark'
              }`}
            >
              <Plus className="h-3 w-3" />
              <span>+ Релиз</span>
            </button>
          </div>

          <AnimatePresence mode="wait">
            
            {/* 1. CREATE RELEASE FLOW */}
            {isCreatingRelease ? (
              <motion.div
                key="create-release"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-sm space-y-6"
              >
                {/* Stepper Header */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="font-display text-lg font-bold text-slate-900">Загрузка музыки на площадки</h3>
                    <p className="text-xs text-slate-500">Следуйте шагам, чтобы отправить релиз на модерацию</p>
                  </div>
                  <button
                    onClick={() => setIsCreatingRelease(false)}
                    className="text-xs font-semibold text-slate-400 hover:text-slate-600 px-3 py-1 bg-slate-50 rounded-md"
                  >
                    Отменить
                  </button>
                </div>

                {/* Steps Visual */}
                <div className="flex items-center gap-3">
                  {[1, 2, 3].map((step) => (
                    <div key={step} className="flex-1 flex items-center gap-2">
                      <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        newReleaseStep === step 
                          ? 'bg-brand-primary text-white' 
                          : newReleaseStep > step 
                          ? 'bg-emerald-100 text-emerald-700' 
                          : 'bg-slate-100 text-slate-400'
                      }`}>
                        {newReleaseStep > step ? <Check className="h-4 w-4" /> : step}
                      </div>
                      <span className={`text-xs font-bold hidden sm:inline ${
                        newReleaseStep === step ? 'text-slate-900' : 'text-slate-400'
                      }`}>
                        {step === 1 && 'Информация'}
                        {step === 2 && 'Файлы и Обложка'}
                        {step === 3 && 'Финальный обзор'}
                      </span>
                      {step < 3 && <div className="flex-1 h-0.5 bg-slate-100" />}
                    </div>
                  ))}
                </div>

                <form onSubmit={handleCreateRelease} className="space-y-6 pt-2">
                  
                  {/* STEP 1: GENERAL INFO */}
                  {newReleaseStep === 1 && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">Название релиза *</label>
                          <input
                            type="text"
                            required
                            placeholder="Например: Solar Wind"
                            value={formRelease.title}
                            onChange={(e) => setFormRelease({ ...formRelease, title: e.target.value })}
                            className="w-full rounded-lg border border-slate-200 px-3.5 py-2 text-sm placeholder-slate-400 focus:border-brand-primary focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">Имя артиста / группы *</label>
                          <input
                            type="text"
                            required
                            placeholder="Основной артист"
                            value={formRelease.artist}
                            onChange={(e) => setFormRelease({ ...formRelease, artist: e.target.value })}
                            className="w-full rounded-lg border border-slate-200 px-3.5 py-2 text-sm placeholder-slate-400 focus:border-brand-primary focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">Жанр *</label>
                          <select
                            value={formRelease.genre}
                            onChange={(e) => setFormRelease({ ...formRelease, genre: e.target.value })}
                            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none"
                          >
                            <option value="Electronic">Electronic</option>
                            <option value="Synthwave">Synthwave</option>
                            <option value="Hip-Hop">Hip-Hop / Rap</option>
                            <option value="Pop">Pop</option>
                            <option value="Rock">Rock / Metal</option>
                            <option value="Ambient">Ambient / Chillout</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">Количество треков *</label>
                          <input
                            type="number"
                            min="1"
                            max="30"
                            required
                            value={formRelease.tracksCount}
                            onChange={(e) => setFormRelease({ ...formRelease, tracksCount: parseInt(e.target.value) || 1 })}
                            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">Дата выхода *</label>
                          <input
                            type="date"
                            required
                            value={formRelease.releaseDate}
                            onChange={(e) => setFormRelease({ ...formRelease, releaseDate: e.target.value })}
                            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end pt-4">
                        <button
                          type="button"
                          onClick={() => setNewReleaseStep(2)}
                          disabled={!formRelease.title || !formRelease.artist}
                          className="px-6 py-2 bg-brand-primary hover:bg-brand-hover text-white text-sm font-bold rounded-lg transition-colors disabled:opacity-50"
                        >
                          Далее
                        </button>
                      </div>
                    </div>
                  )}

                  {/* STEP 2: AUDIO & COVER PRESETS */}
                  {newReleaseStep === 2 && (
                    <div className="space-y-5">
                      {/* Audio upload mockup */}
                      <div className="rounded-xl border-2 border-dashed border-slate-200 p-6 text-center hover:border-brand-primary transition-colors">
                        <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                        <h4 className="text-sm font-bold text-slate-800">Перетащите аудиофайлы (WAV / FLAC)</h4>
                        <p className="text-xs text-slate-400 mt-1">До 100 МБ на один файл. Качество 24-bit / 44.1 kHz</p>
                        <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded bg-brand-light text-brand-dark text-xs font-bold">
                          <Check className="h-3 w-3" />
                          <span>Аудиофайл готов: track_master.wav</span>
                        </div>
                      </div>

                      {/* Cover Preset Selector */}
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-2">Выберите обложку (пресет)</label>
                        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                          {coverPresets.map((preset) => (
                            <button
                              key={preset.id}
                              type="button"
                              onClick={() => setFormRelease({ ...formRelease, coverPreset: preset.id })}
                              className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all ${
                                formRelease.coverPreset === preset.id 
                                  ? 'border-brand-primary scale-95 shadow-md' 
                                  : 'border-transparent opacity-80 hover:opacity-100'
                              }`}
                            >
                              <img src={preset.url} alt={preset.label} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                                <span className="text-[10px] font-bold text-white">{preset.label}</span>
                              </div>
                              {formRelease.coverPreset === preset.id && (
                                <div className="absolute top-2 right-2 bg-brand-primary text-white p-1 rounded-full">
                                  <Check className="h-3 w-3" />
                                </div>
                              )}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex justify-between pt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setNewReleaseStep(1)}
                          className="px-5 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm font-semibold rounded-lg transition-colors"
                        >
                          Назад
                        </button>
                        <button
                          type="button"
                          onClick={() => setNewReleaseStep(3)}
                          className="px-6 py-2 bg-brand-primary hover:bg-brand-hover text-white text-sm font-bold rounded-lg transition-colors"
                        >
                          Далее
                        </button>
                      </div>
                    </div>
                  )}

                  {/* STEP 3: FINAL REVIEW */}
                  {newReleaseStep === 3 && (
                    <div className="space-y-6">
                      <div className="rounded-xl bg-slate-50 p-4 flex flex-col sm:flex-row items-center gap-4 border border-slate-100">
                        <img 
                          src={coverPresets.find(p => p.id === formRelease.coverPreset)?.url} 
                          alt="Cover preview" 
                          className="h-24 w-24 rounded-lg object-cover shadow-sm"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 text-center sm:text-left space-y-1">
                          <span className="text-[10px] uppercase font-bold tracking-widest text-brand-primary">Предпросмотр релиза</span>
                          <h4 className="font-display font-bold text-lg text-slate-900">{formRelease.title || 'Untitled'}</h4>
                          <p className="text-sm font-semibold text-slate-600">{formRelease.artist}</p>
                          <p className="text-xs text-slate-400">Жанр: {formRelease.genre} • Количество треков: {formRelease.tracksCount}</p>
                        </div>
                      </div>

                      <div className="rounded-xl border border-slate-200 p-4 space-y-3 bg-white">
                        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Условия загрузки</h4>
                        <div className="space-y-2 text-xs text-slate-600">
                          <div className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                            <span>Доставка на 80+ платформ, включая Яндекс, VK, Spotify, Apple Music.</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                            <span>Роялти: 85% от прослушиваний зачисляются на ваш баланс.</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                            <span>Модерация релиза займет 1–3 рабочих дня. Вы получите email-уведомление.</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-between pt-4 border-t border-slate-100">
                        <button
                          type="button"
                          onClick={() => setNewReleaseStep(2)}
                          className="px-5 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm font-semibold rounded-lg transition-colors"
                        >
                          Назад
                        </button>
                        <button
                          type="submit"
                          className="px-8 py-2 bg-brand-primary hover:bg-brand-hover text-white text-sm font-bold rounded-lg transition-colors flex items-center gap-2 shadow-md"
                        >
                          <span>Отправить на модерацию</span>
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  )}

                </form>
              </motion.div>
            ) : (
              
              /* 2. REGULAR TABS */
              <div className="space-y-6">
                
                {/* 2.1 OVERVIEW TAB */}
                {activeTab === 'overview' && (
                  <motion.div
                    key="overview-tab"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    {/* Welcome Banner */}
                    <div className="rounded-2xl bg-gradient-to-r from-brand-dark to-brand-primary p-6 md:p-8 text-white relative overflow-hidden shadow-lg">
                      <div className="absolute right-0 bottom-0 top-0 opacity-15 pointer-events-none flex items-center justify-center p-4">
                        <LogoIcon size={200} />
                      </div>
                      <div className="relative z-10 space-y-2 max-w-lg">
                        <span className="text-xs font-bold tracking-widest uppercase bg-white/20 px-2.5 py-0.5 rounded-full">
                          Музыкальная дистрибуция
                        </span>
                        <h3 className="font-display text-2xl md:text-3xl font-bold tracking-tight">
                          Добро пожаловать в NIGHTVOLT!
                        </h3>
                        <p className="text-xs md:text-sm text-brand-light font-medium">
                          Загружайте музыку на все ведущие стриминговые площадки, управляйте правами, следите за статистикой прослушиваний и получайте выплаты без лишних сложностей.
                        </p>
                      </div>
                    </div>

                    {/* Quick Stats Grid */}
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                      <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm flex items-center justify-between">
                        <div>
                          <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Всего прослушиваний</p>
                          <h4 className="text-2xl font-bold text-slate-900 mt-1 font-display">{(totalStreams).toLocaleString('ru-RU')}</h4>
                          <span className="text-[10px] text-emerald-500 font-bold flex items-center gap-0.5 mt-1">
                            <TrendingUp className="h-3 w-3" /> +12.5% за неделю
                          </span>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                          <Play className="h-6 w-6" />
                        </div>
                      </div>

                      <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm flex items-center justify-between">
                        <div>
                          <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Слушатели за месяц</p>
                          <h4 className="text-2xl font-bold text-slate-900 mt-1 font-display">{(monthlyListeners).toLocaleString('ru-RU')}</h4>
                          <span className="text-[10px] text-brand-primary font-bold flex items-center gap-0.5 mt-1">
                            <Users className="h-3 w-3" /> Стабильный рост
                          </span>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-brand-light text-brand-dark flex items-center justify-center">
                          <Users className="h-6 w-6" />
                        </div>
                      </div>

                      <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm flex items-center justify-between">
                        <div>
                          <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Баланс роялти</p>
                          <h4 className="text-2xl font-bold text-slate-900 mt-1 font-display">{balance.toLocaleString('ru-RU')} ₽</h4>
                          <button
                            onClick={() => setActiveTab('financials')}
                            className="text-[10px] text-brand-primary hover:text-brand-hover font-bold flex items-center gap-0.5 mt-1.5"
                          >
                            <span>Запросить выплату</span>
                            <ArrowUpRight className="h-3 w-3" />
                          </button>
                        </div>
                        <div className="h-12 w-12 rounded-lg bg-brand-light text-brand-primary flex items-center justify-center">
                          <Landmark className="h-6 w-6" />
                        </div>
                      </div>
                    </div>

                    {/* Two Column Layout */}
                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
                      
                      {/* Left: Active Releases */}
                      <div className="lg:col-span-2 bg-white rounded-xl border border-slate-150 p-5 shadow-sm space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-display font-bold text-slate-900">Недавние релизы</h4>
                          <button
                            onClick={() => setActiveTab('catalog')}
                            className="text-xs font-semibold text-brand-primary hover:text-brand-hover"
                          >
                            Все релизы
                          </button>
                        </div>

                        <div className="space-y-3">
                          {releases.slice(0, 3).map((rel) => (
                            <div key={rel.id} className="flex items-center justify-between p-3 rounded-xl border border-slate-50 hover:border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-all">
                              <div className="flex items-center gap-3 min-w-0">
                                <img src={rel.coverUrl} alt={rel.title} className="h-11 w-11 rounded-lg object-cover shadow-sm shrink-0" referrerPolicy="no-referrer" />
                                <div className="min-w-0">
                                  <h5 className="text-xs font-bold text-slate-900 truncate">{rel.title}</h5>
                                  <p className="text-[10px] text-slate-400 truncate">{rel.artist}</p>
                                  <span className="text-[9px] text-slate-500">{rel.genre} • {rel.tracksCount} {rel.tracksCount === 1 ? 'трек' : 'трека'}</span>
                                </div>
                              </div>
                              <div className="text-right shrink-0">
                                {rel.status === 'released' && (
                                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                                    <CheckCircle className="h-3 w-3" /> Выпущен
                                  </span>
                                )}
                                {rel.status === 'approved' && (
                                  <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                                    <CheckCircle className="h-3 w-3" /> Утвержден
                                  </span>
                                )}
                                {rel.status === 'moderation' && (
                                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-bold text-amber-700">
                                    <Clock className="h-3 w-3" /> На модерации
                                  </span>
                                )}
                                <p className="text-[10px] text-slate-400 mt-1 font-mono">{rel.upc || 'Pending'}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Right: Support Ticket Quick Status */}
                      <div className="bg-white rounded-xl border border-slate-150 p-5 shadow-sm space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-display font-bold text-slate-900">Служба поддержки</h4>
                          <button
                            onClick={() => setActiveTab('support')}
                            className="text-xs font-semibold text-brand-primary hover:text-brand-hover"
                          >
                            Написать
                          </button>
                        </div>

                        {tickets.length > 0 ? (
                          <div className="space-y-3">
                            {tickets.slice(0, 2).map((ticket) => (
                              <div key={ticket.id} className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/30 text-xs space-y-1.5">
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-slate-900 truncate max-w-[120px]">{ticket.subject}</span>
                                  {ticket.status === 'open' ? (
                                    <span className="text-[9px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">В работе</span>
                                  ) : (
                                    <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Решено</span>
                                  )}
                                </div>
                                <p className="text-slate-500 text-[11px] line-clamp-2">{ticket.message}</p>
                                <p className="text-[10px] text-slate-400 text-right">{ticket.date}</p>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-6 text-slate-400 space-y-2">
                            <HelpCircle className="h-8 w-8 mx-auto stroke-1" />
                            <p className="text-xs">У вас пока нет открытых обращений</p>
                          </div>
                        )}
                      </div>

                    </div>
                  </motion.div>
                )}

                {/* 2.2 CATALOG TAB */}
                {activeTab === 'catalog' && (
                  <motion.div
                    key="catalog-tab"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-display text-xl font-bold text-slate-900">Ваша дискография</h3>
                        <p className="text-xs text-slate-500">Управляйте выпущенными и отправленными на проверку релизами</p>
                      </div>
                      <button
                        onClick={() => setIsCreatingRelease(true)}
                        className="flex items-center gap-1.5 rounded-lg bg-brand-primary px-4 py-2 text-xs font-bold text-white shadow hover:bg-brand-hover transition-colors"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Новый релиз</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      {releases.map((rel) => (
                        <div key={rel.id} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between group">
                          
                          <div className="p-4 space-y-4">
                            {/* Cover art + title */}
                            <div className="flex gap-4">
                              <div className="h-16 w-16 rounded-xl overflow-hidden shadow-sm shrink-0 relative bg-slate-100">
                                <img src={rel.coverUrl} alt={rel.title} className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
                              </div>
                              <div className="min-w-0">
                                <h4 className="font-display font-bold text-sm text-slate-900 truncate" title={rel.title}>
                                  {rel.title}
                                </h4>
                                <p className="text-xs font-semibold text-slate-500 truncate">{rel.artist}</p>
                                <span className="inline-block mt-1 text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 font-bold">
                                  {rel.genre}
                                </span>
                              </div>
                            </div>

                            {/* Release attributes */}
                            <div className="grid grid-cols-2 gap-2 text-[11px] border-t border-slate-100 pt-3">
                              <div>
                                <span className="text-slate-400">Дата выпуска:</span>
                                <p className="font-bold text-slate-800 mt-0.5">{rel.releaseDate}</p>
                              </div>
                              <div>
                                <span className="text-slate-400">Треков:</span>
                                <p className="font-bold text-slate-800 mt-0.5">{rel.tracksCount}</p>
                              </div>
                            </div>
                          </div>

                          {/* Release footer status */}
                          <div className="bg-slate-50 border-t border-slate-100 px-4 py-3 flex items-center justify-between text-xs">
                            <span className="font-mono text-[10px] text-slate-400">{rel.upc || 'UPC Pending'}</span>
                            
                            {rel.status === 'released' && (
                              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                                <CheckCircle className="h-3 w-3" /> Выпущен
                              </span>
                            )}
                            {rel.status === 'approved' && (
                              <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 px-2.5 py-0.5 text-[10px] font-bold text-blue-700">
                                <CheckCircle className="h-3 w-3" /> Утвержден
                              </span>
                            )}
                            {rel.status === 'moderation' && (
                              <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-[10px] font-bold text-amber-700 animate-pulse-subtle">
                                <Clock className="h-3 w-3" /> На модерации
                              </span>
                            )}
                          </div>

                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* 2.3 ANALYTICS TAB */}
                {activeTab === 'analytics' && (
                  <motion.div
                    key="analytics-tab"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div>
                      <h3 className="font-display text-xl font-bold text-slate-900">Аналитический дашборд</h3>
                      <p className="text-xs text-slate-500">Статистика стриминга (только показатели прослушиваний, без географии и демографии)</p>
                    </div>

                    {/* Chart Mockup */}
                    <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 pb-4">
                        <div>
                          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">График прослушиваний за последний месяц</span>
                          <h4 className="font-display font-bold text-lg text-slate-800">Динамика по ключевым платформам</h4>
                        </div>
                        <div className="flex gap-2 text-xs">
                          <span className="px-2 py-1 bg-slate-100 rounded text-slate-600 font-medium">Яндекс Музыка (45%)</span>
                          <span className="px-2 py-1 bg-slate-100 rounded text-slate-600 font-medium">Spotify (28%)</span>
                          <span className="px-2 py-1 bg-slate-100 rounded text-slate-600 font-medium">VK (18%)</span>
                        </div>
                      </div>

                      {/* Custom SVG Bar Chart */}
                      <div className="h-64 flex flex-col justify-between">
                        <div className="flex-1 flex items-end gap-3 pt-6 relative">
                          
                          {/* Grid horizontal lines */}
                          <div className="absolute inset-x-0 top-0 border-t border-slate-100 text-[9px] text-slate-400 pt-1">30 000 стримов</div>
                          <div className="absolute inset-x-0 top-1/3 border-t border-slate-100 text-[9px] text-slate-400 pt-1">20 000 стримов</div>
                          <div className="absolute inset-x-0 top-2/3 border-t border-slate-100 text-[9px] text-slate-400 pt-1">10 000 стримов</div>

                          {/* Bars */}
                          {[
                            { day: "05 Июн", yandex: 40, spotify: 30, vk: 20 },
                            { day: "10 Июн", yandex: 60, spotify: 45, vk: 25 },
                            { day: "15 Июн", yandex: 80, spotify: 50, vk: 35 },
                            { day: "20 Июн", yandex: 95, spotify: 70, vk: 45 },
                            { day: "25 Июн", yandex: 110, spotify: 85, vk: 55 },
                          ].map((bar, idx) => {
                            const totalH = bar.yandex + bar.spotify + bar.vk;
                            return (
                              <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full z-10 group cursor-pointer">
                                {/* Stacked Bar */}
                                <div className="w-full max-w-[40px] rounded-t-lg overflow-hidden flex flex-col justify-end transition-all group-hover:scale-105" style={{ height: `${totalH * 1.5}px` }}>
                                  <div className="bg-[#FFCC00] flex-1" style={{ height: `${bar.yandex}%` }} title="Яндекс Музыка" />
                                  <div className="bg-[#1DB954] flex-1" style={{ height: `${bar.spotify}%` }} title="Spotify" />
                                  <div className="bg-[#0077FF] flex-1" style={{ height: `${bar.vk}%` }} title="VK Музыка" />
                                </div>
                                <span className="text-[10px] font-bold text-slate-500 mt-2 font-display">{bar.day}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Breakdown Cards */}
                      <div className="grid grid-cols-1 gap-4 md:grid-cols-3 pt-4 border-t border-slate-100">
                        <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
                          <span className="text-[10px] font-bold uppercase text-[#FFCC00]">Яндекс Музыка</span>
                          <p className="text-base font-bold text-slate-900">156 728 прослушиваний</p>
                          <p className="text-[10px] text-slate-500">Лидирующий регион: РФ, Казахстан</p>
                        </div>
                        <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
                          <span className="text-[10px] font-bold uppercase text-[#1DB954]">Spotify</span>
                          <p className="text-base font-bold text-slate-900">97 521 прослушиваний</p>
                          <p className="text-[10px] text-slate-500">Лидирующий регион: Германия, США</p>
                        </div>
                        <div className="p-3.5 bg-slate-50 rounded-xl space-y-1">
                          <span className="text-[10px] font-bold uppercase text-[#0077FF]">VK Музыка</span>
                          <p className="text-base font-bold text-slate-900">62 690 прослушиваний</p>
                          <p className="text-[10px] text-slate-500">Лидирующий регион: РФ, Беларусь</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* 2.4 FINANCIALS TAB */}
                {activeTab === 'financials' && (
                  <motion.div
                    key="financials-tab"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <h3 className="font-display text-xl font-bold text-slate-900">Баланс роялти</h3>
                        <p className="text-xs text-slate-500">Прозрачный сбор доходов, вывод на карты РФ и СНГ от 1000 ₽. Ежеквартальные финансовые отчеты автоматически публикуются в вашем личном кабинете.</p>
                      </div>

                      {!isRequestingPayout && (
                        <button
                          onClick={() => setIsRequestingPayout(true)}
                          disabled={balance < 1000}
                          className="rounded-lg bg-brand-primary px-5 py-2.5 text-xs font-bold text-white hover:bg-brand-hover transition-colors shadow-md disabled:opacity-50"
                        >
                          Вывести средства
                        </button>
                      )}
                    </div>

                    {/* Financial balance card */}
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                      
                      {/* Left: Balance */}
                      <div className="md:col-span-1 bg-slate-900 text-white rounded-2xl p-6 shadow-lg flex flex-col justify-between space-y-8 relative overflow-hidden">
                        <div className="absolute right-0 bottom-0 top-0 opacity-10 pointer-events-none flex items-center justify-center p-4">
                          <Wallet size={120} />
                        </div>
                        <div className="space-y-1 relative z-10">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Доступно к выводу</span>
                          <h4 className="text-3xl font-bold font-display">{balance.toLocaleString('ru-RU')} ₽</h4>
                          <p className="text-[10px] text-slate-300 mt-1">Минимальный вывод: 1000 ₽. Комиссия 3–5%</p>
                        </div>

                        <div className="text-[10px] text-slate-400 relative z-10">
                          <span>Лимиты безопасности NIGHTVOLT • Авторизованный аккаунт</span>
                        </div>
                      </div>

                      {/* Right: History */}
                      <div className="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
                        <h4 className="font-display font-bold text-slate-950 text-sm">История операций</h4>

                        <div className="space-y-2.5">
                          {financials.map((record) => (
                            <div key={record.id} className="flex items-center justify-between p-3 rounded-xl border border-slate-50 text-xs">
                              <div>
                                <h5 className="font-bold text-slate-900">{record.description}</h5>
                                <span className="text-[10px] text-slate-400">{record.date}</span>
                              </div>
                              <div className="text-right">
                                <span className={`font-bold text-sm ${record.amount > 0 ? 'text-emerald-600' : 'text-slate-800'}`}>
                                  {record.amount > 0 ? '+' : ''}{record.amount.toLocaleString('ru-RU')} ₽
                                </span>
                                <p className="text-[9px] text-slate-400 mt-0.5">
                                  {record.status === 'completed' ? 'Успешно' : 'Обрабатывается'}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Request Payout Popin */}
                    <AnimatePresence>
                      {isRequestingPayout && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4 overflow-hidden"
                        >
                          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                            <h4 className="font-display font-bold text-slate-900">Запрос на вывод средств</h4>
                            <button
                              onClick={() => setIsRequestingPayout(false)}
                              className="text-xs font-semibold text-slate-400 hover:text-slate-600"
                            >
                              Отмена
                            </button>
                          </div>

                          {payoutSuccess ? (
                            <div className="text-center py-6 space-y-3">
                              <CheckCircle className="h-10 w-10 text-emerald-500 mx-auto" />
                              <h5 className="font-bold text-slate-900">Заявка принята в обработку!</h5>
                              <p className="text-xs text-slate-500 max-w-sm mx-auto">Обычно выплаты поступают на карту в течение 1-2 часов.</p>
                            </div>
                          ) : (
                            <form onSubmit={handleRequestPayout} className="space-y-4">
                              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div>
                                  <label className="block text-xs font-bold text-slate-700 mb-1">Сумма вывода (₽) *</label>
                                  <input
                                    type="number"
                                    required
                                    min="1000"
                                    max={balance}
                                    value={payoutAmount}
                                    onChange={(e) => setPayoutAmount(e.target.value)}
                                    placeholder={`Макс. ${Math.floor(balance)}`}
                                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none"
                                  />
                                </div>
                                <div>
                                  <label className="block text-xs font-bold text-slate-700 mb-1">Номер карты / Счета РФ *</label>
                                  <input
                                    type="text"
                                    required
                                    value={payoutCard}
                                    onChange={(e) => setPayoutCard(e.target.value)}
                                    placeholder="4276 0000 0000 0000"
                                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none"
                                  />
                                </div>
                              </div>

                              <div className="flex justify-end pt-2">
                                <button
                                  type="submit"
                                  className="px-6 py-2 bg-brand-primary hover:bg-brand-hover text-white text-xs font-bold rounded-lg shadow transition-colors"
                                >
                                  Подтвердить и отправить
                                </button>
                              </div>
                            </form>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                )}

                {/* 2.5 SUPPORT TAB */}
                {activeTab === 'support' && (
                  <motion.div
                    key="support-tab"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div>
                      <h3 className="font-display text-xl font-bold text-slate-900">Служба поддержки NIGHTVOLT</h3>
                      <p className="text-xs text-slate-500">Задайте любой вопрос или запросите питчинг в редакции стримингов</p>
                    </div>

                    <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                      
                      {/* Left form: Create Ticket */}
                      <div className="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
                        <h4 className="font-display font-bold text-slate-900 text-sm">Создать новое обращение</h4>
                        
                        <form onSubmit={handleCreateTicket} className="space-y-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">Тема обращения *</label>
                            <input
                              type="text"
                              required
                              value={ticketSubject}
                              onChange={(e) => setTicketSubject(e.target.value)}
                              placeholder="Например: Питчинг альбома Solar Wind"
                              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">Текст сообщения *</label>
                            <textarea
                              required
                              rows={4}
                              value={ticketMessage}
                              onChange={(e) => setTicketMessage(e.target.value)}
                              placeholder="Опишите детально ваш вопрос или запрос..."
                              className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-brand-primary focus:outline-none resize-none"
                            />
                          </div>

                          <div className="flex justify-end">
                            <button
                              type="submit"
                              disabled={isSubmittingTicket}
                              className="px-6 py-2 bg-brand-primary hover:bg-brand-hover text-white text-xs font-bold rounded-lg shadow transition-colors disabled:opacity-50"
                            >
                              {isSubmittingTicket ? 'Отправка...' : 'Отправить тикет'}
                            </button>
                          </div>
                        </form>
                      </div>

                      {/* Right list: My Tickets */}
                      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4 flex flex-col justify-between">
                        <div>
                          <h4 className="font-display font-bold text-slate-900 text-sm mb-3">Ваши обращения</h4>
                          <div className="space-y-3">
                            {tickets.map((t) => (
                              <div key={t.id} className="p-3 bg-slate-50 rounded-xl space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs font-bold text-slate-900 truncate max-w-[120px]">{t.subject}</span>
                                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                    t.status === 'open' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'
                                  }`}>
                                    {t.status === 'open' ? 'В работе' : 'Решено'}
                                  </span>
                                </div>
                                <p className="text-[10px] text-slate-500 line-clamp-2">{t.message}</p>
                                <span className="text-[9px] text-slate-400 block text-right">{t.date}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="pt-4 border-t border-slate-100 text-xs text-slate-400">
                          <p>Наши операторы работают Пн-Вс: 10:00 - 22:00 по МСК</p>
                        </div>
                      </div>

                    </div>
                  </motion.div>
                )}

              </div>
            )}

          </AnimatePresence>

        </div>
      </main>

    </div>
  );
};
