/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

// Import platform logos from /src/components/platforms/
import appleLogo from './platforms/apple.png';
import deezerLogo from './platforms/deezer.png';
import instagramLogo from './platforms/instagram.png';
import spotifyLogo from './platforms/spotify.png';
import tiktokLogo from './platforms/tiktok.png';
import vkLogo from './platforms/vk.png';
import yandexLogo from './platforms/yandex.png';
import youtubeLogo from './platforms/youtube.png';
import zvukLogo from './platforms/zvuk.png';

interface IconProps extends React.SVGProps<SVGSVGElement> {
  size?: number;
  className?: string;
}

// 1. Label/Brand Logo Icon
export const LogoIcon: React.FC<IconProps> = ({ size = 32, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="lightning-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#2563EB" />
        <stop offset="50%" stopColor="#1D4ED8" />
        <stop offset="100%" stopColor="#1E40AF" />
      </linearGradient>
    </defs>
    {/* Underlay dark shadow for extra visibility */}
    <path
      d="M 15.5 19.8 L 44.2 16.5 L 27.5 24.3 L 34.1 31.2 L 3.5 36.2 L 22.2 26.5 Z"
      fill="#0F172A"
      opacity="0.15"
    />
    {/* Main Lightning Bolt */}
    <path
      d="M 15.5 18.8 L 44.2 15.5 L 27.5 23.3 L 34.1 30.2 L 3.5 35.2 L 22.2 25.5 Z"
      fill="url(#lightning-gradient)"
      stroke="#0F172A"
      strokeWidth="2.5"
      strokeLinejoin="miter"
      strokeMiterlimit="4"
    />
    {/* Stylized highlight inner core */}
    <path
      d="M 16.5 19.8 L 41.5 16.8 L 28.5 23.8 L 32.5 29.8"
      stroke="#93C5FD"
      strokeWidth="1"
      strokeLinecap="round"
      opacity="0.6"
    />
  </svg>
);

// 2. Personal Cabinet
export const CabinetIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <rect x="3" y="3" width="18" height="18" rx="2" stroke="#2563EB" />
    <path d="M9 17V9" />
    <path d="M15 17V13" />
    <path d="M3 9h18" stroke="#2563EB" opacity="0.5" />
  </svg>
);

// 3. Fast Moderation
export const ModerationIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <circle cx="12" cy="12" r="10" stroke="#2563EB" />
    <polyline points="12 6 12 12 16 14" />
    <path d="M12 2a10 10 0 0 1 8.2 4.5" stroke="#2563EB" strokeWidth="2.5" />
  </svg>
);

// 4. Promo Support
export const PromoIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="rgba(37, 99, 235, 0.1)" stroke="#2563EB" />
    <line x1="12" y1="2" x2="12" y2="6" stroke="#2563EB" />
    <line x1="22" y1="9.27" x2="18" y2="10" stroke="#2563EB" />
  </svg>
);

// 5. Personal Support
export const SupportIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" stroke="#2563EB" />
    <path d="M23 18.6V12.4a3.4 3.4 0 0 0-3.4-3.4h-1.2" stroke="#2563EB" strokeDasharray="2 2" />
    <circle cx="19" cy="12" r="1.5" fill="#2563EB" stroke="none" />
  </svg>
);

// 6. Detailed Analytics
export const AnalyticsIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <line x1="18" y1="20" x2="18" y2="10" stroke="#2563EB" />
    <line x1="12" y1="20" x2="12" y2="4" />
    <line x1="6" y1="20" x2="6" y2="14" stroke="#2563EB" />
    <path d="M3 20h18" strokeWidth="2.5" />
  </svg>
);

// 7. Platforms (Globe/Multi-Ring)
export const PlatformsIcon: React.FC<IconProps> = ({ size = 24, className = "", ...props }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <circle cx="12" cy="12" r="10" />
    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" stroke="#2563EB" />
    <path d="M2 12h20" stroke="#2563EB" />
  </svg>
);

// Platform Image Loader with Fallback
const PlatformImageLoader: React.FC<{
  src: string;
  className?: string;
  fallback: React.ReactNode;
}> = ({ src, className = "h-6 w-auto", fallback }) => {
  const [hasError, setHasError] = React.useState(false);
  const [isLoaded, setIsLoaded] = React.useState(false);

  React.useEffect(() => {
    if (!src) {
      setHasError(true);
    }
  }, [src]);

  return (
    <div className="flex items-center justify-center">
      {!hasError && src && (
        <img
          src={src}
          alt="Platform Logo"
          className={`${className} max-h-7 object-contain ${!isLoaded ? 'hidden' : 'block'}`}
          onError={() => setHasError(true)}
          onLoad={() => setIsLoaded(true)}
        />
      )}
      {(hasError || !isLoaded) && <div className={isLoaded ? 'hidden' : 'block'}>{fallback}</div>}
    </div>
  );
};

// Platform Logo Renderers (High quality, consistent dimensions)
export const PlatformLogo: React.FC<{ name: string; className?: string }> = ({ name, className = "" }) => {
  const normName = name.toLowerCase();

  if (normName.includes('spotify')) {
    return (
      <PlatformImageLoader
        src={spotifyLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 114 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="16" cy="17" r="14" fill="#1DB954" />
            <path d="M25.5 13.5C21.2 11 14.1 10.7 10 12C9.3 12.2 8.6 11.8 8.4 11.1C8.2 10.4 8.6 9.7 9.3 9.5C14.1 8 21.9 8.3 26.9 11.3C27.5 11.7 27.7 12.5 27.3 13.1C26.9 13.7 26.1 13.9 25.5 13.5ZM25.3 17.5C24.9 18.1 24.1 18.3 23.5 17.9C19.9 15.7 14.5 15.1 10.5 16.3C9.8 16.5 9.1 16.1 8.9 15.4C8.7 14.7 9.1 14 9.8 13.8C14.4 12.4 20.4 13.1 24.5 15.6C25.1 16 25.3 16.9 25.3 17.5ZM23.3 21.3C23 21.8 22.3 22 21.8 21.7C18.7 19.8 14.8 19.4 10.3 20.4C9.7 20.5 9.1 20.1 9 19.5C8.9 18.9 9.3 18.3 9.9 18.2C14.8 17.1 19.1 17.6 22.7 19.8C23.2 20.1 23.4 20.8 23.3 21.3Z" fill="white" />
            <text x="36" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="18" fill="#1DB954" letterSpacing="-0.5">Spotify</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('youtube')) {
    return (
      <PlatformImageLoader
        src={youtubeLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 140 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="5" width="34" height="24" rx="6" fill="#FF0000" />
            <path d="M15 11L24 17L15 23V11Z" fill="white" />
            <text x="42" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="17" fill="#1e293b" letterSpacing="-0.5">YouTube</text>
            <text x="110" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="500" fontSize="11" fill="#ef4444" letterSpacing="0.2">MUSIC</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('vk')) {
    return (
      <PlatformImageLoader
        src={vkLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 110 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="3" width="28" height="28" rx="8" fill="#0077FF" />
            <path d="M16 22c-5.1 0-8-3.5-8.1-9.2h2.5c.1 4.2 2 6 3.4 6.3V12.8h2.4v3.6c1.5-.2 3-1.8 3.5-3.6h2.4c-.4 2.3-2.1 3.9-3.3 4.5 1.2.6 3.1 2 4.7 4.7H21.2c-1.3-1.8-2.7-3.2-3.8-3.1h-.9v3.1H16z" fill="white" />
            <text x="36" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="18" fill="#0077FF" letterSpacing="-0.5">VK</text>
            <text x="64" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="500" fontSize="14" fill="#334155">Музыка</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('яндекс') || normName.includes('yandex')) {
    return (
      <PlatformImageLoader
        src={yandexLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 145 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="16" cy="17" r="14" fill="#FFCC00" />
            <circle cx="16" cy="17" r="9" fill="#1E293B" />
            <circle cx="16" cy="17" r="4" fill="#FFCC00" />
            <text x="36" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="17" fill="#1E293B" letterSpacing="-0.5">Яндекс</text>
            <text x="96" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="500" fontSize="16" fill="#f59e0b">Музыка</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('звук') || normName.includes('zvuk')) {
    return (
      <PlatformImageLoader
        src={zvukLogo}
        className={className}
        fallback={
          <div className="flex items-center gap-1.5">
            <svg 
              className={`h-6 w-6 shrink-0 ${className}`} 
              viewBox="10 0 80 92" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M42 4 C65.2 4 84 22.8 84 46 C84 69.2 65.2 88 42 88 C24.2 88 15.6 76.1 15.6 66.8 C31.5 66.8 36.8 53.9 36.8 46 C36.8 38.1 31.5 25.2 15.6 25.2 C15.6 15.9 24.2 4 42 4 Z" fill="#24FF00" />
              <path d="M31.4 27.7 L44.6 46.2 L31.4 64.7 H39.3 L48.6 51.5 L57.8 64.7 H65.7 L52.5 46.2 L65.7 27.7 H57.8 L48.6 40.9 L39.3 27.7 H31.4 Z" fill="white" />
            </svg>
            <span className="font-display font-black text-slate-900 tracking-tight text-xs leading-none">ЗВУК</span>
          </div>
        }
      />
    );
  }

  if (normName.includes('deezer')) {
    return (
      <PlatformImageLoader
        src={deezerLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 110 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g fill="#a855f7">
              <rect x="2" y="20" width="5" height="4" rx="1" />
              <rect x="9" y="18" width="5" height="6" rx="1" />
              <rect x="16" y="14" width="5" height="10" rx="1" fill="#ec4899" />
              <rect x="23" y="10" width="5" height="14" rx="1" fill="#e11d48" />
            </g>
            <text x="34" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="18" fill="#1e293b" letterSpacing="-0.2">deezer</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('tiktok')) {
    return (
      <PlatformImageLoader
        src={tiktokLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 110 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="3" width="28" height="28" rx="14" fill="#000000" />
            <path d="M19 10a5 5 0 0 1-3 3v8a4 4 0 1 1-4-4 4 4 0 0 1 1 .1V13a6 6 0 1 0 5 5v-8h1z" fill="#00f2fe" />
            <path d="M18.8 10a5 5 0 0 1-3 3v8a4 4 0 1 1-4-4 4 4 0 0 1 1 .1V13a6 6 0 1 0 5 5v-8h1z" fill="#fe0979" style={{ mixBlendMode: 'screen' }} />
            <text x="36" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="18" fill="#000000" letterSpacing="-0.5">TikTok</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('apple') || normName.includes('music')) {
    return (
      <PlatformImageLoader
        src={appleLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 110 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15.2 6c-1.1 0-2.4.7-3.1 1.5-.7.8-1.2 2-1.1 3.2 1.1 0 2.3-.7 3-1.6.7-.8 1.1-2 1.2-3.1zM17.6 11.2c-.8-.5-1.9-.9-2.9-.9-2.3 0-3.5 1.4-4 1.4-.5 0-1.5-1.2-3.3-1.2-2.1 0-4.1 1.6-4.1 4.5 0 3.3 2.5 7.6 4.9 7.6 1.1 0 1.9-.7 2.9-.7 1 0 1.6.7 2.8.7 2.3 0 4.5-4 4.5-4.1 0 0-2.1-1-2.1-3.2 0-1.9 1.7-2.9 1.7-2.9-.8-1.2-2.4-1.2-2.4-1.2z" fill="#fc3c44" />
            <text x="26" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="18" fill="#1e293b" letterSpacing="-0.5">Music</text>
          </svg>
        }
      />
    );
  }

  if (normName.includes('instagram') || normName.includes('ig')) {
    return (
      <PlatformImageLoader
        src={instagramLogo}
        className={className}
        fallback={
          <svg className={`h-6 w-auto ${className}`} viewBox="0 0 120 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="3" width="28" height="28" rx="8" fill="url(#ig-grad-icons)" />
            <rect x="7" y="8" width="18" height="18" rx="5" stroke="white" strokeWidth="2" fill="none" />
            <circle cx="16" cy="17" r="4" stroke="white" strokeWidth="2" fill="none" />
            <circle cx="21.5" cy="11.5" r="1" fill="white" />
            <defs>
              <radialGradient id="ig-grad-icons" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" transform="translate(6 28) rotate(-45) scale(38)">
                <stop offset="0" stopColor="#FED976" />
                <stop offset="0.25" stopColor="#FEB24C" />
                <stop offset="0.5" stopColor="#FD8D3C" />
                <stop offset="0.75" stopColor="#FC4E2A" />
                <stop offset="1" stopColor="#E31A1C" />
              </radialGradient>
            </defs>
            <text x="36" y="23" fontFamily="Plus Jakarta Sans, sans-serif" fontWeight="800" fontSize="16" fill="#E1306C" letterSpacing="-0.5">Instagram</text>
          </svg>
        }
      />
    );
  }

  // Fallback beautiful label icon
  return (
    <div className="flex items-center gap-1">
      <div className="h-3 w-3 rounded-full bg-brand-primary" />
      <span className="font-display font-semibold text-sm text-slate-700">{name}</span>
    </div>
  );
};

