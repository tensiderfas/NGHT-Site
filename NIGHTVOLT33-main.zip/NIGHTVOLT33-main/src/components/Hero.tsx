/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Check, Play, Disc, ChevronDown, TrendingUp, Radio, Sparkles, Users2 } from 'lucide-react';
import { LogoIcon } from './CustomIcons';

interface HeroProps {
  onRegisterClick: () => void;
  onLearnMoreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onRegisterClick, onLearnMoreClick }) => {
  return (
    <section id="hero" className="relative min-h-[calc(100vh-80px)] flex items-center justify-center bg-white overflow-hidden py-12 md:py-20 px-6">
      
      {/* Background Soft Glows (Professional, light-theme) */}
      <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-brand-light rounded-full blur-[120px] opacity-60 pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[350px] h-[350px] bg-slate-100 rounded-full blur-[80px] opacity-50 pointer-events-none" />

      <div className="mx-auto max-w-7xl w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        
        {/* Left Column: Copy & Actions */}
        <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 rounded-full bg-slate-50 border border-slate-100 px-4 py-1.5 text-xs font-semibold text-slate-600 shadow-sm"
            >
              <span className="flex h-2 w-2 rounded-full bg-brand-primary animate-pulse" />
              <span>Цифровая дистрибуция нового поколения</span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="inline-flex flex-wrap items-center gap-x-3 gap-y-1 rounded-full bg-brand-light/70 border border-brand-primary/10 px-4 py-1.5 text-xs font-bold text-slate-700 shadow-sm"
            >
              <span className="text-[10px] text-brand-primary uppercase tracking-wider font-extrabold">Контакты:</span>
              <a href="mailto:nightvolt@internet.ru" className="text-brand-dark hover:text-brand-primary transition-colors underline decoration-brand-primary/20">nightvolt@internet.ru</a>
              <span className="text-slate-300 select-none">•</span>
              <a href="mailto:label@nightvolt.ru" className="text-brand-dark hover:text-brand-primary transition-colors underline decoration-brand-primary/20">label@nightvolt.ru</a>
            </motion.div>
          </div>

          <div className="space-y-4">
            <motion.h2
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.05] lens-hover cursor-default"
            >
              Ваша музыка <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary via-brand-hover to-brand-dark">
                на всех платформах
              </span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-base sm:text-lg text-slate-500 max-w-2xl mx-auto lg:mx-0 font-medium leading-relaxed lens-hover cursor-default"
            >
              Доносим ваше творчество до миллионов слушателей. Выпускаем музыку на все ключевые площадки — от Яндекс Музыки до Spotify. Получайте до 85% роялти и профессиональную поддержку на каждом этапе.
            </motion.p>
          </div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4"
          >
            <button
              onClick={onRegisterClick}
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-brand-primary px-8 py-4 text-sm font-bold text-white shadow-lg shadow-brand-light hover:bg-brand-hover hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
            >
              <span>Начать дистрибуцию</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={onLearnMoreClick}
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-white border border-slate-200 px-8 py-4 text-sm font-bold text-slate-700 hover:text-brand-primary hover:border-brand-primary hover:bg-slate-50/50 transition-all cursor-pointer"
            >
              Узнать больше
            </button>
          </motion.div>

          {/* Quick stats on left */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="grid grid-cols-2 gap-4 max-w-sm mx-auto lg:mx-0 pt-4"
          >
            <div className="bg-slate-50/80 border border-slate-100 p-4 rounded-2xl lens-hover cursor-default">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display block">40+</span>
              <span className="text-xs font-semibold text-slate-400 mt-1 block">Выпущенных релизов</span>
            </div>
            <div className="bg-slate-50/80 border border-slate-100 p-4 rounded-2xl lens-hover cursor-default">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display block">100+</span>
              <span className="text-xs font-semibold text-slate-400 mt-1 block">Активных аккаунтов</span>
            </div>
          </motion.div>
        </div>

        {/* Right Column: High Fidelity Abstract Geometric Mockup */}
        <div className="lg:col-span-5 relative hidden sm:flex items-center justify-center h-[520px]">
          
          {/* Target concentric circles */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-[420px] h-[420px] rounded-full border border-slate-100/80 flex items-center justify-center">
              <div className="w-[310px] h-[310px] rounded-full border border-slate-100/60 flex items-center justify-center">
                <div className="w-[200px] h-[200px] rounded-full border border-slate-100/40 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-brand-light flex items-center justify-center">
                    <LogoIcon className="text-brand-primary animate-pulse-subtle" size={28} />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Real SaaS Dashboard elements from reference image */}
          
          {/* Card 1: Top Right - "ДИНАМИКА" / "Прослушивания" with live animated bars */}
          <motion.div
            initial={{ opacity: 0, x: 45, y: -30 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ type: 'spring', damping: 15, delay: 0.2 }}
            className="absolute top-2 -right-6 w-72 bg-white border border-slate-200/90 rounded-2xl p-5 shadow-lg z-10 hover:shadow-xl transition-all duration-300 select-none cursor-default"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-50">
              <div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">ДИНАМИКА</span>
                <h4 className="text-sm font-extrabold text-slate-800 mt-0.5">Прослушивания</h4>
              </div>
              <span className="inline-flex items-center bg-emerald-50 text-emerald-500 rounded-md text-[10px] px-2 py-0.5 font-bold">
                +18.2%
              </span>
            </div>

            {/* Smooth animated bar charts imitating stream growth */}
            <div className="h-20 flex items-end justify-between gap-2 px-1 pt-4">
              {[
                { heightClass: 'h-1/3', delay: 0.1, isHighlighted: false },
                { heightClass: 'h-2/3', delay: 0.2, isHighlighted: false },
                { heightClass: 'h-1/2', delay: 0.3, isHighlighted: true },
                { heightClass: 'h-4/5', delay: 0.4, isHighlighted: false },
                { heightClass: 'h-full', delay: 0.5, isHighlighted: true },
                { heightClass: 'h-3/5', delay: 0.6, isHighlighted: false },
              ].map((bar, i) => (
                <div key={i} className="flex-1 bg-slate-50 rounded-md h-full flex items-end">
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: '100%' }}
                    transition={{ type: 'spring', stiffness: 80, damping: 12, delay: bar.delay }}
                    className={`w-full rounded-md ${bar.isHighlighted ? 'bg-brand-primary' : 'bg-brand-light'}`}
                    style={{ maxHeight: i === 0 ? '30%' : i === 1 ? '50%' : i === 2 ? '42%' : i === 3 ? '60%' : i === 4 ? '85%' : '40%' }}
                  />
                </div>
              ))}
            </div>

            {/* Footer indicator with active dot */}
            <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-50">
              <span className="h-2 w-2 rounded-full bg-brand-primary animate-pulse" />
              <span className="text-[10px] text-slate-400 font-semibold tracking-wide">
                Яндекс, Spotify, VK • Прямой эфир
              </span>
            </div>
          </motion.div>

          {/* Card 2: Middle Floating - "НОВЫЕ СЛУШАТЕЛИ" with silhouette icon */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: 'spring', damping: 15, delay: 0.4 }}
            className="absolute top-[48%] left-[45%] -translate-x-1/2 -translate-y-1/2 bg-white border border-slate-200/90 rounded-2xl p-3.5 shadow-xl flex items-center gap-3 z-20 hover:scale-105 transition-all duration-300 select-none cursor-default"
          >
            <div className="h-9 w-9 rounded-xl bg-brand-light/70 text-brand-primary flex items-center justify-center shrink-0">
              <Users2 className="h-4 w-4" />
            </div>
            <div>
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">НОВЫЕ СЛУШАТЕЛИ</span>
              <p className="text-xs font-black text-slate-800 leading-none mt-0.5">+4,290 сегодня</p>
            </div>
          </motion.div>

          {/* Card 3: Bottom Left - "Поддержка в Telegram" */}
          <motion.div
            initial={{ opacity: 0, x: -45, y: 30 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ type: 'spring', damping: 15, delay: 0.6 }}
            className="absolute bottom-2 -left-6 w-64 bg-white border border-slate-200/90 rounded-2xl p-4 shadow-lg z-10 hover:shadow-xl hover:border-emerald-100 transition-all duration-300 select-none cursor-default"
          >
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse-subtle shrink-0" />
              <h5 className="text-xs font-extrabold text-slate-800">Поддержка в Telegram</h5>
            </div>
            <p className="text-[10px] text-slate-400 font-semibold leading-relaxed mt-2 tracking-wide">
              Живой менеджер отвечает до 12 часов. Помогаем с релизами напрямую.
            </p>
          </motion.div>

        </div>

      </div>

      {/* Bounce indicator bottom */}
      <div 
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 opacity-60 hover:opacity-100 transition-opacity cursor-pointer hidden sm:flex" 
        onClick={() => {
          const target = document.getElementById('partners') || document.getElementById('about-us');
          if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      >
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Прокрутите ниже</span>
        <ChevronDown className="h-4 w-4 text-brand-primary animate-bounce" />
      </div>

    </section>
  );
};
