/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Target, Shield, Landmark, Globe } from 'lucide-react';

export const AboutUs: React.FC = () => {
  return (
    <section id="about-us" className="py-16 md:py-24 bg-white relative overflow-hidden px-6">
      <div className="mx-auto max-w-7xl relative z-10">
        
        {/* Title */}
        <div className="text-center space-y-2 mb-16">
          <h3 className="font-display text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
            Создаём будущее <span className="text-brand-primary">музыкальной дистрибуции</span>
          </h3>
          <p className="text-sm font-medium text-slate-500 max-w-2xl mx-auto">
            Помогаем независимым артистам и крупным музыкальным объединениям эффективно доносить творчество до слушателей.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Block: Narrative & Cards */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-4 text-slate-600 text-sm sm:text-base font-medium leading-relaxed">
              <p>
                <strong>NIGHTVOLT Distribution</strong> — это не просто дистрибьютор, а технологический партнер с индивидуальным подходом к каждому музыканту. Мы доставляем ваши релизы на все мировые и локальные стриминговые платформы, предоставляем удобную аналитику, помогаем с редакторским питчингом и собираем ваши роялти.
              </p>
              <p>
                Мы убрали сложные цепочки посредников и скрытые комиссии. От загрузки первого трека до формирования финансовых отчетов — мы гарантируем прозрачность, скорость и круглосуточную персональную помощь.
              </p>
            </div>

            {/* Inner Cards Grid: Mission and Values */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="bg-slate-50 border border-slate-100 p-5 rounded-2xl space-y-3">
                <div className="h-10 w-10 rounded-lg bg-brand-light text-brand-primary flex items-center justify-center">
                  <Target className="h-5 w-5" />
                </div>
                <h4 className="font-display font-bold text-slate-900 text-sm">Наша миссия</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">
                  Дать независимым исполнителям любого масштаба профессиональные инструменты дистрибуции, равные возможностям крупных лейблов.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-100 p-5 rounded-2xl space-y-3">
                <div className="h-10 w-10 rounded-lg bg-emerald-50 text-emerald-500 flex items-center justify-center">
                  <Shield className="h-5 w-5" />
                </div>
                <h4 className="font-display font-bold text-slate-900 text-sm">Наши ценности</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">
                  Абсолютная финансовая прозрачность, технологичность интерфейсов, оперативность модерации и фокус на долгосрочном успехе артиста.
                </p>
              </div>
            </div>
          </div>

          {/* Right Block: Interactive SaaS Stats Frame (Image 4 right side style) */}
          <div className="lg:col-span-5">
            <div className="bg-brand-light/30 border border-brand-light/60 rounded-3xl p-6 md:p-8 space-y-6 shadow-sm">
              
              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-lg bg-brand-primary text-white flex items-center justify-center font-bold text-sm">
                  NV
                </div>
                <div>
                  <h4 className="font-display font-bold text-slate-900 text-sm leading-none">NIGHTVOLT</h4>
                  <span className="text-[10px] text-slate-400 font-bold">Музыкальный дистрибьютор</span>
                </div>
              </div>

              {/* Grid of four numbers */}
              <div className="grid grid-cols-2 gap-4">
                
                <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm">
                  <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display block">40+</span>
                  <p className="text-xs font-bold text-slate-400 mt-1">Релизов</p>
                </div>

                <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm">
                  <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display block">100+</span>
                  <p className="text-xs font-bold text-slate-400 mt-1">Создано аккаунтов</p>
                </div>

                <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm">
                  <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display block">2025</span>
                  <p className="text-xs font-bold text-slate-400 mt-1">Год основания</p>
                </div>

                <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm">
                  <span className="text-2xl sm:text-3xl font-extrabold text-[#2563EB] font-display block">80+</span>
                  <p className="text-xs font-bold text-slate-400 mt-1">Площадок доставки</p>
                </div>

              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
