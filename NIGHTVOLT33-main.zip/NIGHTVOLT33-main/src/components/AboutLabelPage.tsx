import React from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Target, ShieldCheck, HelpCircle, Flame, Star, Sparkles, Milestone, Users2, Library } from 'lucide-react';

interface AboutLabelPageProps {
  onBack: () => void;
  onContactClick: (planName: string) => void;
}

export const AboutLabelPage: React.FC<AboutLabelPageProps> = ({ onBack, onContactClick }) => {
  return (
    <div className="min-h-screen bg-slate-50 py-16 md:py-24">
      <div className="mx-auto max-w-4xl px-6">
        
        {/* Navigation Breadcrumb */}
        <motion.button
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          onClick={onBack}
          className="group mb-10 inline-flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-950 transition-colors bg-white border border-slate-200 px-4 py-2 rounded-xl shadow-sm hover:shadow transition-all cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4 group-hover:-translate-x-1 transition-transform" />
          <span>Назад на главную</span>
        </motion.button>

        {/* Hero Header */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="space-y-4 mb-16 text-center max-w-3xl mx-auto"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[#2563EB]/10 px-3 py-1 text-xs font-bold text-[#2563EB] tracking-wide uppercase">
            <Sparkles className="h-3.5 w-3.5 animate-pulse" /> О нашем лейбле
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-none">
            NIGHTVOLT Distribution & Label
          </h2>
          <p className="text-sm sm:text-base font-medium text-slate-500 leading-relaxed max-w-2xl mx-auto">
            Мы создали технологическую экосистему для независимых артистов и лейблов. Наша цель — убрать лишних посредников и дать вам полный контроль над своей музыкой, роялти и карьерой.
          </p>
        </motion.div>

        {/* Detailed Narrative Section */}
        <div className="space-y-12">
          
          {/* Block 1: Who We Are */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm space-y-6"
          >
            <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
              <div className="h-10 w-10 rounded-xl bg-[#2563EB]/10 flex items-center justify-center text-[#2563EB]">
                <Library className="h-5 w-5" />
              </div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-slate-900">Кто мы такие?</h3>
            </div>
            
            <div className="text-slate-600 text-xs sm:text-sm leading-relaxed font-medium space-y-4">
              <p>
                <strong>NIGHTVOLT</strong> — это музыкальная компания нового поколения, сочетающая функции высокотехнологичного дистрибьютора и независимого издательства. Мы родились как ответ на классические бюрократизированные лейблы, которые часто забирают большую часть прибыли артиста, предлагая взамен минимум прозрачности.
              </p>
              <p>
                Мы верим, что современный музыкант должен иметь доступ к прямым, прозрачным инструментам доставки контента на витрины. Наша IT-платформа соединяет вас напрямую с крупнейшими шлюзами (включая Zvonko Digital, Believe Music, Яндекс, VK и Apple Music), обеспечивая безупречное качество метаданных, мгновенный питчинг и выплаты без задержек.
              </p>
            </div>
          </motion.div>

          {/* Block 2: Interactive Bento Grid of Services */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Core Card 1 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4"
            >
              <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center">
                <Flame className="h-5 w-5" />
              </div>
              <h4 className="font-display font-bold text-slate-900 text-sm sm:text-base">Профессиональный Питчинг</h4>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                Мы берем на себя взаимодействие с редакторами Яндекс Музыки, VK Музыки, Звука и других платформ. Подаем ваши треки в официальные кураторские плейлисты, на витрины и баннерную поддержку, помогая релизам находить стартовую аудиторию.
              </p>
            </motion.div>

            {/* Core Card 2 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4"
            >
              <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <h4 className="font-display font-bold text-slate-900 text-sm sm:text-base">Юридическая Чистота</h4>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                Оказываем юридическую помощь в защите авторских и смежных прав. Осуществляем регистрацию каталогов, помогаем при несанкционированном копировании вашего творчества и предоставляем официальные отчеты о сборах.
              </p>
            </motion.div>

            {/* Core Card 3 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4"
            >
              <div className="h-10 w-10 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center">
                <Target className="h-5 w-5" />
              </div>
              <h4 className="font-display font-bold text-slate-900 text-sm sm:text-base">Прозрачная Финтех-Аналитика</h4>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                Вы видите подробную статистику по каждому релизу, треку и региону. Никаких скрытых комиссий, "ошибок" округления или долгих ожиданий — вы забираете до 85% собранных роялти и выводите их удобным для вас способом.
              </p>
            </motion.div>

            {/* Core Card 4 */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4"
            >
              <div className="h-10 w-10 rounded-xl bg-purple-50 text-purple-500 flex items-center justify-center">
                <Users2 className="h-5 w-5" />
              </div>
              <h4 className="font-display font-bold text-slate-900 text-sm sm:text-base">Индивидуальный Менеджмент</h4>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                Забудьте об обезличенных тикетах техподдержки, на которые отвечают неделями. В NIGHTVOLT с каждым партнером общается квалифицированный аккаунт-менеджер напрямую в Telegram, решая любые вопросы оперативно и вовлеченно.
              </p>
            </motion.div>

          </div>

          {/* Block 3: Our Philosophy & Milestone */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm space-y-6"
          >
            <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
              <div className="h-10 w-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                <Milestone className="h-5 w-5" />
              </div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-slate-900">Наша философия</h3>
            </div>
            
            <div className="text-slate-600 text-xs sm:text-sm leading-relaxed font-medium space-y-4">
              <p>
                Мы убеждены, что творческий процесс заслуживает максимального уважения. Наша задача — снять с артиста всю головную боль по оформлению релизов, расчету долей фитов, ведению переговоров с витринами и контролю выплат. 
              </p>
              <p>
                Будь вы начинающий инди-артист с первым синглом или крупный лейбл со старым каталогом в сотни треков — вы получите одинаково внимательное отношение, быструю модерацию (в среднем до 24 часов) и максимальные шансы на успешное продвижение вашей музыки.
              </p>
            </div>
          </motion.div>

          {/* Call to Action */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="bg-slate-900 rounded-3xl p-8 sm:p-12 text-center text-white relative overflow-hidden shadow-xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#2563EB]/15 via-transparent to-[#2563EB]/5 pointer-events-none" />
            <div className="relative z-10 max-w-xl mx-auto space-y-6">
              <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-[#2563EB] uppercase tracking-widest bg-[#2563EB]/10 px-2.5 py-1 rounded-full">
                <Star className="h-3.5 w-3.5 text-brand-primary" /> Станьте частью семьи Nightvolt
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight">Начнем сотрудничество?</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Подайте заявку на дистрибуцию сегодня. Наш специалист свяжется с вами для обсуждения промо-плана и предоставит доступ в личный кабинет.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => onContactClick('Лейбл')}
                  className="w-full sm:w-auto rounded-xl bg-[#2563EB] px-8 py-4 text-xs font-bold text-white hover:bg-brand-hover hover:scale-[1.02] active:scale-95 transition-all shadow-md cursor-pointer"
                >
                  Оставить заявку на дистрибуцию
                </button>
              </div>
            </div>
          </motion.div>

        </div>

      </div>
    </div>
  );
};
