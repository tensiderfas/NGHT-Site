/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { COMPARISON_DATA } from '../data';
import { Check, X } from 'lucide-react';

export const Comparison: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-white px-6">
      <div className="mx-auto max-w-4xl">
        
        {/* Header */}
        <div className="text-center space-y-2 mb-12">
          <h3 className="font-display text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            Сравнение с конкурентами
          </h3>
          <p className="text-sm font-medium text-slate-500">
            Посмотрите, почему независимые артисты переходят на платформу NIGHTVOLT.
          </p>
        </div>

        {/* Table Container */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200/80 shadow-sm bg-white">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-400 w-1/2">Функция</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-brand-dark w-1/4 text-center">NIGHTVOLT</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-400 w-1/4 text-center">Конкуренты</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {COMPARISON_DATA.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  {/* Feature Label */}
                  <td className="px-6 py-4 text-xs sm:text-sm font-semibold text-slate-700">
                    {row.feature}
                  </td>
                  
                  {/* NIGHTVOLT Value */}
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center">
                      {typeof row.nightvolt === 'boolean' ? (
                        row.nightvolt ? (
                          <div className="inline-flex items-center gap-1 bg-brand-light text-brand-dark px-2.5 py-1 rounded-full text-[11px] font-bold">
                            <Check className="h-3.5 w-3.5 text-brand-primary" strokeWidth={3} />
                            <span>Да</span>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 px-2.5 py-1 rounded-full text-[11px] font-bold">
                            <X className="h-3.5 w-3.5 text-rose-500" strokeWidth={3} />
                            <span>Нет</span>
                          </div>
                        )
                      ) : (
                        <div className="inline-flex items-center gap-1 bg-brand-light text-brand-dark px-2.5 py-1 rounded-full text-[11px] font-bold">
                          <Check className="h-3.5 w-3.5 text-brand-primary" strokeWidth={3} />
                          <span>{row.nightvolt}</span>
                        </div>
                      )}
                    </div>
                  </td>

                  {/* Competitors Value */}
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center">
                      {typeof row.competitors === 'boolean' ? (
                        row.competitors ? (
                          <div className="inline-flex items-center gap-1 text-slate-500 text-xs font-semibold">
                            <Check className="h-3.5 w-3.5 text-slate-400" />
                            <span>Да</span>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1 bg-rose-50/50 text-rose-500 px-2.5 py-1 rounded-full text-[11px] font-bold">
                            <X className="h-3.5 w-3.5 text-rose-400" strokeWidth={3} />
                            <span>Нет</span>
                          </div>
                        )
                      ) : (
                        <div className="inline-flex items-center gap-1 text-slate-500 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-full text-[11px] font-bold">
                          <X className="h-3.5 w-3.5 text-slate-400" strokeWidth={3} />
                          <span>{row.competitors}</span>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </section>
  );
};
