/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Info, KeyRound } from 'lucide-react';
import { PRICING_DATA } from '../data';

interface PricingProps {
  onPlanSelect: (planName: string) => void;
}

export const Pricing: React.FC<PricingProps> = ({ onPlanSelect }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually'>('annually');

  return (
    <section id="pricing" className="py-16 md:py-24 bg-slate-50 border-y border-slate-100 px-6 relative">
      
      {/* Absolute glow decorative elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-light/20 rounded-full blur-[140px] pointer-events-none" />

      <div className="mx-auto max-w-7xl relative z-10 space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-3">
          <h3 className="font-display text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
            План под <span className="text-brand-primary">ваши задачи</span>
          </h3>
          <p className="text-sm font-medium text-slate-500 max-w-xl mx-auto">
            Выберите оптимальный тариф под объем ваших релизов и бизнес-цели — без скрытых удержаний и комиссий.
          </p>

          {/* Billing Switcher Toggle (Image 3 visual reference) */}
          <div className="pt-4 flex items-center justify-center">
            <div className="bg-white border border-slate-200/80 p-1 rounded-xl flex items-center gap-1 shadow-sm">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  billingCycle === 'monthly'
                    ? 'bg-slate-900 text-white shadow'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                Месячная оплата
              </button>
              <button
                onClick={() => setBillingCycle('annually')}
                className={`relative px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  billingCycle === 'annually'
                    ? 'bg-slate-900 text-white shadow'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <span>Годовая оплата</span>
                <span className="bg-brand-primary/15 text-brand-dark px-1.5 py-0.5 rounded text-[9px] font-extrabold animate-pulse">
                  Выгодно
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Pricing Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {PRICING_DATA.map((plan) => {
            const isAnnually = billingCycle === 'annually';
            const price = isAnnually ? plan.priceAnnually : plan.priceMonthly;
            const savingAmount = isAnnually ? (plan.priceMonthly * 12) - plan.priceAnnually : 0;

            return (
              <motion.div
                key={plan.id}
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className={`bg-white rounded-3xl border p-6 md:p-8 flex flex-col justify-between shadow-sm relative transition-all ${
                  plan.isPopular
                    ? 'border-brand-primary ring-2 ring-brand-light/60 shadow-xl md:scale-[1.03] z-10'
                    : 'border-slate-200/85'
                }`}
              >
                {/* Badges / Labels */}
                {plan.isPopular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-brand-primary text-white text-[10px] font-extrabold px-3.5 py-1 rounded-full uppercase tracking-widest flex items-center gap-1 shadow-md">
                    <span>Популярный</span>
                  </div>
                )}
                {plan.isMaximum && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-extrabold px-3.5 py-1 rounded-full uppercase tracking-widest flex items-center gap-1 shadow">
                    <span>Максимум</span>
                  </div>
                )}

                <div className="space-y-6">
                  {/* Card Title & Desc */}
                  <div>
                    <h4 className="font-display text-lg font-extrabold text-slate-900">{plan.name}</h4>
                    <p className="text-xs text-slate-400 font-semibold mt-1 leading-relaxed">{plan.description}</p>
                  </div>

                  {/* Price display */}
                  {plan.id === 'label' ? (
                    <div className="space-y-1 min-h-[58px] flex flex-col justify-center">
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl sm:text-3xl font-extrabold text-slate-950 font-display">Индивидуально</span>
                      </div>
                      <p className="text-[10px] text-slate-400 font-semibold leading-normal">
                        Бесплатно при рассмотрении
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-1 min-h-[58px] flex flex-col justify-center">
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl font-extrabold text-slate-950 font-display">{price} ₽</span>
                        <span className="text-xs font-semibold text-slate-400">
                          {isAnnually && plan.priceAnnually > 0 ? '/ в год (разово)' : '/ в месяц'}
                        </span>
                      </div>
                      {isAnnually && savingAmount > 0 && (
                        <p className="text-[10px] text-emerald-500 font-bold">
                          Экономия {savingAmount} ₽ в год
                        </p>
                      )}
                    </div>
                  )}

                  {/* Feature lists */}
                  <div className="h-px bg-slate-100 my-4" />

                  <ul className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-600 font-medium">
                        <Check className="h-4 w-4 text-[#2563EB] shrink-0 mt-0.5" strokeWidth={3} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Call to action button */}
                <div className="pt-8">
                  <button
                    onClick={() => onPlanSelect(plan.name)}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all shadow-sm ${
                      plan.isPopular
                        ? 'bg-[#2563EB] text-white hover:bg-[#1D4ED8] hover:scale-[1.01]'
                        : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    Выбрать {plan.name}
                  </button>
                </div>

              </motion.div>
            );
          })}
        </div>

        {/* Footnote information cards */}
        <div className="max-w-3xl mx-auto space-y-3">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center gap-3">
            <Info className="h-5 w-5 text-[#2563EB] shrink-0" />
            <p className="text-[11px] text-slate-500 font-medium">
              <strong>Обратите внимание:</strong> Все выплаты роялти осуществляются в рублях напрямую на банковские карты любых банков РФ и СНГ с комиссией от 3% до 5%. Мы работаем открыто и без скрытых платежей.
            </p>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 flex items-center gap-3">
            <KeyRound className="h-5 w-5 text-[#2563EB] shrink-0" />
            <p className="text-[11px] text-slate-500 font-medium">
              <strong>Персональные суб-кабинеты:</strong> Мы в индивидуальном порядке предоставляем музыкальным лейблам выделенные суб-кабинеты у наших партнеров-дистрибьюторов для независимого отслеживания поставок и расширенного контроля контента. Каждая заявка рассматривается строго индивидуально.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
