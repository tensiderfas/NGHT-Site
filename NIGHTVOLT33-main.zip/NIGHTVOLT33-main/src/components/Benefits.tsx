/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { BENEFIT_DATA } from '../data';
import { 
  CabinetIcon, 
  ModerationIcon, 
  PromoIcon, 
  SupportIcon, 
  AnalyticsIcon, 
  PlatformsIcon 
} from './CustomIcons';

export const Benefits: React.FC = () => {
  
  // Dynamic icon selector based on key
  const renderIcon = (iconName: string) => {
    const commonClasses = "text-brand-primary h-6 w-6";
    switch (iconName) {
      case 'cabinet':
        return <CabinetIcon className={commonClasses} />;
      case 'moderation':
        return <ModerationIcon className={commonClasses} />;
      case 'promo':
        return <PromoIcon className={commonClasses} />;
      case 'support':
        return <SupportIcon className={commonClasses} />;
      case 'analytics':
        return <AnalyticsIcon className={commonClasses} />;
      case 'platforms':
        return <PlatformsIcon className={commonClasses} />;
      default:
        return <CabinetIcon className={commonClasses} />;
    }
  };

  return (
    <section id="benefits" className="py-16 md:py-24 bg-slate-50 border-y border-slate-100 px-6">
      <div className="mx-auto max-w-7xl">
        
        {/* Header (Image 2 style) */}
        <div className="text-center space-y-2 mb-16">
          <h3 className="font-display text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
            Почему выбирают <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-hover">NIGHTVOLT</span>
          </h3>
          <p className="text-sm font-medium text-slate-500 max-w-2xl mx-auto">
            Всё для дистрибуции и успешного продвижения вашего творчества в одном месте.
          </p>
        </div>

        {/* Benefits Grid (Image 2 cards style: 3x2) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {BENEFIT_DATA.map((benefit, index) => (
            <motion.div
              key={benefit.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-brand-primary/40 hover:-translate-y-0.5 transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                {/* Minimal circle for custom SVG Icon */}
                <div className="h-12 w-12 rounded-xl bg-brand-light flex items-center justify-center transition-transform group-hover:scale-105 duration-300">
                  {renderIcon(benefit.iconName)}
                </div>
                
                <h4 className="font-display font-bold text-slate-900 text-base">
                  {benefit.title}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">
                  {benefit.description}
                </p>
              </div>

              {/* Little bottom subtle branding element */}
              <div className="pt-4 flex justify-end">
                <span className="text-[10px] text-slate-300 font-bold tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  NIGHTVOLT
                </span>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
