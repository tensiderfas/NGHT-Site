/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu, X, Globe, User } from 'lucide-react';
import { LogoIcon } from './CustomIcons';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onNavigate: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onLoginClick, onRegisterClick, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { label: 'Главная', id: 'hero' },
    { label: 'Партнеры', id: 'partners-page' },
    { label: 'О нас', id: 'about-us' },
    { label: 'Преимущества', id: 'benefits' },
    { label: 'Тарифы', id: 'pricing' },
    { label: 'FAQ', id: 'faq' }
  ];

  const handleLinkClick = (id: string) => {
    setMobileMenuOpen(false);
    onNavigate(id);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-slate-100">
      <div className="mx-auto max-w-7xl px-6 h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <button 
          onClick={() => handleLinkClick('hero')} 
          className="flex items-center gap-3 group focus:outline-none"
        >
          <div className="text-brand-primary group-hover:scale-105 transition-transform">
            <LogoIcon size={36} />
          </div>
          <div className="text-left">
            <h1 className="font-display font-extrabold text-lg text-slate-900 tracking-tight leading-none">
              NIGHTVOLT
            </h1>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-0.5">
              Distribution
            </span>
          </div>
        </button>

        {/* Desktop Menu */}
        <nav className="hidden lg:flex items-center gap-8">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="text-sm font-semibold text-slate-600 hover:text-brand-primary transition-colors cursor-pointer"
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Desktop Auth Actions */}
        <div className="hidden lg:flex items-center gap-4">
          <button
            onClick={onLoginClick}
            className="rounded-lg px-4 py-2 text-sm font-bold text-slate-700 hover:text-brand-primary hover:bg-slate-50 transition-all cursor-pointer border border-transparent hover:border-slate-100"
          >
            Войти
          </button>
          <button
            onClick={onRegisterClick}
            className="rounded-lg bg-brand-primary px-5 py-2.5 text-sm font-bold text-white shadow-md shadow-brand-light hover:bg-brand-hover hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
          >
            Регистрация
          </button>
        </div>

        {/* Mobile menu trigger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-slate-600 hover:text-slate-900 lg:hidden focus:outline-none"
          aria-label="Toggle Menu"
          id="toggle-mobile-menu"
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="lg:hidden border-t border-slate-100 bg-white"
          >
            <div className="px-6 py-6 space-y-4">
              <div className="flex flex-col gap-3">
                {menuItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleLinkClick(item.id)}
                    className="text-left py-2 text-base font-semibold text-slate-700 hover:text-brand-primary transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="h-px bg-slate-100 my-4" />

              <div className="flex flex-col gap-3 pt-2">
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => { setMobileMenuOpen(false); onLoginClick(); }}
                    className="rounded-lg border border-slate-200 py-3 text-center text-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    Войти
                  </button>
                  <button
                    onClick={() => { setMobileMenuOpen(false); onRegisterClick(); }}
                    className="rounded-lg bg-brand-primary py-3 text-center text-sm font-bold text-white shadow-md hover:bg-brand-hover transition-all"
                  >
                    Регистрация
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
