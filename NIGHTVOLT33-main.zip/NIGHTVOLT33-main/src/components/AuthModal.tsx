/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Mail, Lock, LogIn, ArrowRight } from 'lucide-react';
import { LogoIcon } from './CustomIcons';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (email: string) => void;
  defaultMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, 
  onClose, 
  onSuccess, 
  defaultMode = 'login' 
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(defaultMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  React.useEffect(() => {
    setMode(defaultMode);
  }, [defaultMode, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onSuccess(email);
      onClose();
    }, 1000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', duration: 0.5 }}
            className="relative w-full max-w-md overflow-hidden rounded-2xl bg-white p-6 shadow-2xl md:p-8"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
              id="close-auth-modal"
            >
              <X className="h-5 w-5" />
            </button>

            {/* Header branding */}
            <div className="text-center space-y-3 mb-6">
              <div className="mx-auto h-12 w-12 rounded-xl bg-brand-light text-brand-primary flex items-center justify-center">
                <LogoIcon size={32} />
              </div>
              <div>
                <h3 className="font-display text-xl font-bold text-slate-900">
                  {mode === 'login' ? 'Войти в личный кабинет' : 'Регистрация аккаунта'}
                </h3>
                <p className="text-xs text-slate-500">
                  NIGHTVOLT Distribution — музыкальная платформа нового поколения
                </p>
              </div>
            </div>

            {/* Auth Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Электронная почта (Email) *
                </label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    placeholder="your@name.ru"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 pl-10 pr-4 py-2 text-sm placeholder-slate-400 focus:border-brand-primary focus:outline-none"
                  />
                  <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Пароль *
                </label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 pl-10 pr-4 py-2 text-sm placeholder-slate-400 focus:border-brand-primary focus:outline-none"
                  />
                  <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                </div>
              </div>

              {mode === 'register' && (
                <div className="rounded-lg bg-slate-50 border border-slate-100 p-3 text-[10px] text-slate-500 leading-normal">
                  Регистрируясь, вы соглашаетесь с условиями дистрибьюторского соглашения NIGHTVOLT и обработкой персональных данных.
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-brand-primary py-3 text-sm font-bold text-white shadow-md shadow-brand-light hover:bg-brand-hover hover:scale-[1.01] transition-all disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                ) : (
                  <>
                    <span>{mode === 'login' ? 'Войти' : 'Создать кабинет'}</span>
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </form>

            {/* Toggle Mode */}
            <div className="mt-6 text-center text-xs text-slate-400 font-semibold">
              {mode === 'login' ? (
                <p>
                  Впервые у нас?{' '}
                  <button
                    onClick={() => setMode('register')}
                    className="text-brand-primary hover:underline font-bold"
                  >
                    Зарегистрируйтесь
                  </button>
                </p>
              ) : (
                <p>
                  Уже есть аккаунт?{' '}
                  <button
                    onClick={() => setMode('login')}
                    className="text-brand-primary hover:underline font-bold"
                  >
                    Войти в кабинет
                  </button>
                </p>
              )}
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
