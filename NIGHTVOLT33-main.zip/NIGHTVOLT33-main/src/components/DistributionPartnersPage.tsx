/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Globe2, KeyRound, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface DistributionPartnersPageProps {
  onBack: () => void;
  onContactClick: (planName: string) => void;
}

// 1. Custom High-Fidelity SVG for Zvonko Digital (100% Complete & Uncropped)
export const ZvonkoLogo: React.FC<{ className?: string }> = ({ className = "h-12 w-auto" }) => (
  <svg 
    className={className} 
    viewBox="0 0 540 140" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M15 70 L115 20 L115 70 Z" fill="currentColor" />
    <path d="M115 70 L115 120 L215 70 Z" fill="currentColor" />
    <g fill="currentColor">
      <text x="240" y="68" fontFamily="Plus Jakarta Sans, system-ui, sans-serif" fontWeight="800" fontSize="56" letterSpacing="-1.5">zvonko</text>
      <text x="240" y="112" fontFamily="Plus Jakarta Sans, system-ui, sans-serif" fontWeight="500" fontSize="42" letterSpacing="-0.5">digital</text>
    </g>
  </svg>
);

// 2. Custom High-Fidelity SVG for Sundesire Media (100% Complete & Uncropped, Fallback Logo)
export const SundesireLogo: React.FC<{ className?: string }> = ({ className = "h-12 w-auto" }) => (
  <svg 
    className={className} 
    viewBox="0 0 540 140" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="sunGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#2563EB" />
        <stop offset="50%" stopColor="#3B82F6" />
        <stop offset="100%" stopColor="#60A5FA" />
      </linearGradient>
    </defs>
    <g transform="translate(15, 15)">
      {/* Sun icon with warm energy waves */}
      <circle cx="55" cy="55" r="32" fill="url(#sunGradient)" />
      <path d="M15 55 C 35 35, 75 75, 95 55" stroke="white" strokeWidth="4.5" strokeLinecap="round" />
      <path d="M25 65 C 45 45, 65 85, 85 65" stroke="white" strokeWidth="5" strokeLinecap="round" />
    </g>
    <g fill="currentColor">
      <text x="140" y="65" fontFamily="Plus Jakarta Sans, system-ui, sans-serif" fontWeight="800" fontSize="52" letterSpacing="-1.5">sundesire</text>
      <text x="140" y="110" fontFamily="Plus Jakarta Sans, system-ui, sans-serif" fontWeight="500" fontSize="38" letterSpacing="1" opacity="0.8">media</text>
    </g>
  </svg>
);

// 3. Custom High-Fidelity SVG for Believe (100% Complete & Uncropped, Wordmark Logo, Matching User's Image 3)
export const BelieveLogo: React.FC<{ className?: string }> = ({ className = "h-12 w-auto" }) => (
  <svg 
    className={className} 
    viewBox="0 0 380 110" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <g transform="translate(10, 5)">
      <text x="10" y="78" fontFamily="Plus Jakarta Sans, system-ui, sans-serif" fontWeight="800" fontSize="76" fill="currentColor" letterSpacing="-2.5">believ</text>
      <g transform="translate(262, 11)">
        <path d="M45 46 C45 32 36 24 25 24 C14 24 5 33 5 47 C5 61 14 70 26 70 C36 70 44 63 46 53 H36 C34 56 31 59 26 59 C20 59 15 54 15 47 H45 V46 Z M15 40 C16 33 20 30 25 30 C30 30 34 33 35 40 H15 Z" fill="currentColor" />
        <circle cx="25" cy="47" r="3" fill="currentColor" />
        <path d="M25 32 A 15 15 0 0 1 40 47" stroke="#FF0000" strokeWidth="5" strokeLinecap="round" />
        <path d="M25 22 A 25 25 0 0 1 50 47" stroke="#FF0000" strokeWidth="5" strokeLinecap="round" />
        <path d="M25 12 A 35 35 0 0 1 60 47" stroke="#FF0000" strokeWidth="5" strokeLinecap="round" />
      </g>
    </g>
  </svg>
);

// ==========================================================
// НАСТРОЙКА ВАШИХ СОБСТВЕННЫХ ЛОГОТИПОВ
// ==========================================================
// Вы можете заменить встроенные логотипы на свои собственные файлы (например, PNG, SVG или JPG).
// По умолчанию настроены пути к файлам в папке `/public/logos/`.
// Просто загрузите ваши файлы с именами `zvonko.png`, `believe.png` и `sundesire.png`
// в папку `/public/logos/` через файловый менеджер слева, и они заменят текущие логотипы автоматически!
export const CUSTOM_LOGOS = {
  zvonko: '/logos/zvonko.png',  // путь к логотипу Zvonko Digital
  believe: '/logos/believe.png', // путь к логотипу Believe Music
  sundesire: '/logos/sundesire.png', // путь к логотипу Sundesire Media
};

// Вспомогательный компонент для загрузки изображения с автоматическим откатом на SVG,
// если файл еще не загружен пользователем (чтобы избежать "битой картинки")
const ImageWithFallback: React.FC<{
  src: string;
  alt: string;
  className?: string;
  fallback: React.ReactNode;
}> = ({ src, alt, className, fallback }) => {
  const [hasError, setHasError] = React.useState(false);

  if (!src || hasError) {
    return <>{fallback}</>;
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      onError={() => setHasError(true)}
    />
  );
};

export const DistributionPartnersPage: React.FC<DistributionPartnersPageProps> = ({ onBack, onContactClick }) => {
  const getLogo = (id: 'zvonko' | 'believe' | 'sundesire', defaultLogo: React.ReactNode) => {
    const customPath = CUSTOM_LOGOS[id];
    return (
      <ImageWithFallback
        src={customPath}
        alt={id}
        className="max-h-12 max-w-full object-contain"
        fallback={defaultLogo}
      />
    );
  };

  const mainPartners = [
    {
      id: 'zvonko' as const,
      logo: getLogo('zvonko', <ZvonkoLogo className="h-10 sm:h-11 text-slate-950" />),
      description: 'Zvonko Digital — крупнейший российский музыкальный дистрибьютор, занимающий лидирующие позиции на рынке СНГ. Обеспечивает прямую доставку треков на все ведущие российские и международные стриминговые платформы, включая VK Музыку, Яндекс Музыку, Звук, Apple Music и YouTube. Сервис предлагает расширенные инструменты аналитики, маркетинговое сопровождение, содействие в получении промо-поддержки и эффективное управление авторскими правами.',
    },
    {
      id: 'believe' as const,
      logo: getLogo('believe', <BelieveLogo className="h-10 sm:h-11 text-slate-950" />),
      description: 'Believe — ведущая мировая технологическая компания в сфере цифровой дистрибуции музыки со штаб-квартирой в Париже. Помогает независимым исполнителям и лейблам развивать аудиторию на локальном и глобальном уровнях, предоставляя инновационные цифровые решения, дистрибуцию на более чем 150 платформ по всему миру, комплексный маркетинг и экспертную поддержку.',
    },
    {
      id: 'sundesire' as const,
      logo: getLogo('sundesire', <SundesireLogo className="h-10 sm:h-11 text-slate-950" />),
      description: 'Sundesire Media — надежный международный музыкальный дистрибьютор, предоставляющий независимым артистам и музыкальным лейблам комплексные услуги по доставке контента на все ключевые глобальные и локальные музыкальные витрины. Предлагает инструменты для точного анализа стриминга, прозрачные отчеты о роялти, юридическую поддержку и индивидуальное консультирование для успешного масштабирования музыкального бизнеса.',
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50/50 py-12">
      <div className="mx-auto max-w-4xl px-6">
        
        {/* Navigation Breadcrumb */}
        <motion.button
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          onClick={onBack}
          className="group mb-10 inline-flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-950 transition-colors bg-white border border-slate-200 px-4 py-2 rounded-xl shadow-sm hover:shadow transition-all cursor-pointer"
        >
          <ArrowLeft className="h-3.5 w-3.5 group-hover:-translate-x-1 transition-transform" />
          <span>Назад на главную</span>
        </motion.button>

        {/* Section Heading */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="space-y-4 mb-14 text-center max-w-2xl mx-auto"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[#2563EB]/10 px-3 py-1 text-xs font-bold text-[#2563EB] tracking-wide uppercase">
            <Globe2 className="h-3.5 w-3.5" /> Прямая дистрибуция
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Наши партнеры по дистрибьюции
          </h2>
          <p className="text-sm font-medium text-slate-500 leading-relaxed">
            Мы работаем напрямую с лидерами музыкальной индустрии. Никаких серых схем или длинных цепочек посредников — ваши релизы поступают в официальные шлюзы напрямую, гарантируя точность метаданных и быстрые выплаты роялти.
          </p>
        </motion.div>

        {/* The Grid of Main Partners */}
        <div className="space-y-6">
          {mainPartners.map((partner, index) => (
            <motion.div
              key={partner.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
              className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm hover:shadow-md hover:border-brand-primary/20 transition-all duration-300"
            >
              <div className="flex flex-col md:flex-row gap-6 md:gap-8 items-start md:items-center">
                
                {/* Left Side: Logo Box */}
                <div className="w-full md:w-56 shrink-0 bg-slate-50 border border-slate-100 rounded-xl p-6 flex items-center justify-center min-h-[100px] hover:bg-slate-100/50 transition-colors duration-300">
                  {partner.logo}
                </div>

                {/* Right Side: Description */}
                <div className="flex-1">
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-medium">
                    {partner.description}
                  </p>
                </div>

              </div>
            </motion.div>
          ))}
        </div>

        {/* Explanatory Info Card on Sub-cabinets (No Emojis) */}
        <div className="mt-10 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-[#2563EB]/10 flex items-center justify-center shrink-0">
              <KeyRound className="h-6 w-6 text-[#2563EB]" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Выделенные суб-кабинеты для музыкальных лейблов</h4>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                В рамках стратегического партнерства мы в индивидуальном порядке предоставляем квалифицированным музыкальным лейблам персональные субаккаунты у дистрибьюторов (Zvonko, Believe). Это открывает доступ к расширенному управлению контентом, прямой аналитике и независимому контролю поставок. Каждая заявка на выделение кабинета рассматривается строго индивидуально в ручном режиме.
              </p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 bg-slate-900 rounded-3xl p-8 sm:p-12 text-center text-white relative overflow-hidden shadow-xl">
          <div className="absolute inset-0 bg-gradient-to-r from-brand-primary/10 via-transparent to-brand-primary/5 pointer-events-none" />
          <div className="relative z-10 max-w-xl mx-auto space-y-6">
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#2563EB] uppercase tracking-widest bg-[#2563EB]/10 px-2.5 py-1 rounded-full">
              <Sparkles className="h-3 w-3" /> Начните сотрудничество
            </span>
            <h3 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight">Готовы масштабировать свой лейбл?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Оставьте заявку на дистрибуцию, чтобы получить доступ к прямым каналам поставок Believe и Zvonko, персональной поддержке 24/7 и индивидуальным условиям распределения роялти.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onContactClick('Лейбл')}
                className="w-full sm:w-auto rounded-xl bg-[#2563EB] px-6 py-3 text-xs font-bold text-white hover:bg-brand-hover hover:scale-[1.02] active:scale-95 transition-all shadow-md cursor-pointer"
              >
                Подать заявку на партнерство
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
