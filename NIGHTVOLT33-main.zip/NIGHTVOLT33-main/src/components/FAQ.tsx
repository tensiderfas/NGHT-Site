/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle, MessageSquare } from 'lucide-react';
import { FAQ_DATA } from '../data';

interface FAQProps {
  onContactClick: () => void;
}

export const FAQ: React.FC<FAQProps> = ({ onContactClick }) => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const toggleItem = (idx: number) => {
    if (expandedIndex === idx) {
      setExpandedIndex(null);
    } else {
      setExpandedIndex(idx);
    }
  };

  return (
    <section id="faq" className="py-16 md:py-24 bg-white px-6">
      <div className="mx-auto max-w-3xl space-y-16">
        
        {/* Header (Image 1 style) */}
        <div className="text-center space-y-2">
          <h3 className="font-display text-3xl font-extrabold text-slate-900 tracking-tight">
            Часто задаваемые вопросы
          </h3>
          <p className="text-sm font-medium text-slate-500 max-w-xl mx-auto">
            Ответы на популярные вопросы о нашем сервисе музыкальной дистрибуции.
          </p>
        </div>

        {/* Accordions list */}
        <div className="space-y-3">
          {FAQ_DATA.map((item, idx) => {
            const isExpanded = expandedIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-slate-200/80 overflow-hidden bg-white hover:border-brand-primary/30 transition-colors"
              >
                {/* Trigger Row */}
                <button
                  onClick={() => toggleItem(idx)}
                  className="w-full flex items-center justify-between p-5 text-left transition-colors hover:bg-slate-50/50"
                  id={`faq-trigger-${idx}`}
                >
                  <span className="text-xs sm:text-sm font-bold text-slate-800 pr-4">
                    {item.question}
                  </span>
                  <div className={`text-slate-400 p-1.5 rounded-lg bg-slate-50 transition-transform ${isExpanded ? 'rotate-180 text-brand-primary' : ''}`}>
                    <ChevronDown className="h-4 w-4" />
                  </div>
                </button>

                {/* Animated Drawer */}
                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                    >
                      <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-500 leading-relaxed font-medium border-t border-slate-100">
                        {item.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

        {/* Footer Contact CTA block (Image 1 style) */}
        <div className="bg-slate-50 rounded-2xl border border-slate-100 p-8 text-center space-y-6">
          <div className="space-y-1.5">
            <h4 className="font-display text-lg font-bold text-slate-900">
              Остались вопросы?
            </h4>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto font-medium">
              Свяжитесь с нами напрямую по электронной почте или отправьте быстрое сообщение через форму ниже.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 text-xs font-bold text-slate-700">
            <a 
              href="mailto:nightvolt@internet.ru" 
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 bg-white rounded-xl border border-slate-200/60 hover:text-brand-primary hover:border-brand-primary/40 transition-all shadow-sm"
            >
              <span className="text-slate-400 font-medium">Поддержка:</span>
              <span className="underline decoration-slate-200 hover:decoration-brand-primary">nightvolt@internet.ru</span>
            </a>
            <a 
              href="mailto:label@nightvolt.ru" 
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 bg-white rounded-xl border border-slate-200/60 hover:text-brand-primary hover:border-brand-primary/40 transition-all shadow-sm"
            >
              <span className="text-slate-400 font-medium">Лейбл:</span>
              <span className="underline decoration-slate-200 hover:decoration-brand-primary">label@nightvolt.ru</span>
            </a>
          </div>

          <div className="flex items-center justify-center gap-2 text-slate-200 select-none">
            <span className="h-px w-8 bg-current" />
            <span className="text-[10px] font-black tracking-widest text-slate-400 uppercase">ИЛИ</span>
            <span className="h-px w-8 bg-current" />
          </div>

          <button
            onClick={onContactClick}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-primary px-6 py-3 text-xs font-extrabold text-white shadow-md shadow-brand-light hover:bg-brand-hover hover:scale-[1.01] transition-all cursor-pointer"
          >
            <MessageSquare className="h-4 w-4" />
            <span>Заполнить форму обратной связи</span>
          </button>
        </div>

      </div>
    </section>
  );
};
