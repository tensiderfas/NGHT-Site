/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PlatformLogo } from './CustomIcons';

export const Partners: React.FC = () => {
  const platforms = [
    'Spotify',
    'Yandex Music',
    'VK Music',
    'YouTube Music',
    'Apple Music',
    'Zvuk',
    'Deezer',
    'TikTok',
    'Instagram'
  ];

  return (
    <section id="partners" className="py-12 bg-slate-50 border-y border-slate-100 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6">
        
        {/* Header (Image 4 visual style) */}
        <div className="text-center space-y-2 mb-10">
          <h3 className="font-display text-2xl font-extrabold text-slate-900 tracking-tight">
            Вас услышат везде
          </h3>
          <p className="text-sm font-medium text-slate-500 max-w-2xl mx-auto">
            Сотрудничаем с ведущими мировыми и локальными платформами — ваша музыка попадает к миллионам слушателей.
          </p>
        </div>

        {/* Horizontal scroll or layout grid of platform cards */}
        <div className="relative">
          {/* Subtle gradient fades on the edge to signify scrolling */}
          <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-slate-50 to-transparent pointer-events-none z-10 hidden sm:block" />
          <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-slate-50 to-transparent pointer-events-none z-10 hidden sm:block" />

          {/* Scrolling Container */}
          <div className="flex gap-4 overflow-x-auto pb-4 pt-1 px-4 scrollbar-none snap-x justify-start md:justify-center">
            {platforms.map((plat) => (
              <div
                key={plat}
                className="flex-shrink-0 bg-white border border-slate-200/60 rounded-xl px-5 py-4 flex items-center justify-center shadow-sm hover:shadow-md hover:border-brand-primary transition-all duration-300 snap-center min-w-[140px]"
              >
                <PlatformLogo name={plat} />
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
